﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.RegularExpressions;

namespace CarolinaHandling.HiveQR.Sync
{
    public class SyncLastLocation : IPlugin
    {
        private const string AccessKey = "EOeqHUxEH4TgZhpf9S7brQ874GRAWsYn";
        private const bool EnableDiagnostics = true;

        // ===============================
        // Facility rules
        // ===============================
        private static readonly Dictionary<string, string[]> FacilityRules =
            new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase)
        {
            { "ISC", new[] { "isc", "greenville", "piedmont" } },
            { "CLT", new[] { "clt", "charlotte" } },
            { "ATL", new[] { "fbn", "georgia" } },
            { "BHM", new[] { "bhm", "alabama" } },
            { "GBO", new[] { "gbo", "greensboro" } },
            { "RAL", new[] { "ral", "raleigh" } }
        };

        private static readonly Dictionary<string, int> FacilityOptionCache =
            new Dictionary<string, int>();

        private static string Normalize(string val)
        {
            if (string.IsNullOrWhiteSpace(val)) return null;
            return Regex.Replace(val.Trim().ToUpperInvariant(), @"\s+", " ");
        }

        private static string PickFacilityCode(string city, string name)
        {
            var c = (city ?? "").ToLowerInvariant();
            var n = (name ?? "").ToLowerInvariant();

            foreach (var rule in FacilityRules)
            {
                foreach (var token in rule.Value)
                {
                    if (c.Contains(token) || n.Contains(token))
                        return rule.Key;
                }
            }
            return null;
        }

        private static int? GetFacilityOptionValue(
            IOrganizationService service,
            string attributeLogicalName,
            string label)
        {
            if (string.IsNullOrWhiteSpace(label))
                return null;

            var cacheKey = attributeLogicalName + "|" + label;
            if (FacilityOptionCache.TryGetValue(cacheKey, out var cached))
                return cached;

            var req = new RetrieveAttributeRequest
            {
                EntityLogicalName = "ch_unifiedequipment",
                LogicalName = attributeLogicalName,
                RetrieveAsIfPublished = true
            };

            var resp = (RetrieveAttributeResponse)service.Execute(req);
            var meta = (PicklistAttributeMetadata)resp.AttributeMetadata;

            foreach (var opt in meta.OptionSet.Options)
            {
                if (opt.Label?.UserLocalizedLabel != null &&
                    string.Equals(
                        opt.Label.UserLocalizedLabel.Label,
                        label,
                        StringComparison.OrdinalIgnoreCase))
                {
                    FacilityOptionCache[cacheKey] = opt.Value.Value;
                    return opt.Value.Value;
                }
            }

            return null;
        }

        // ===============================
        // Execute
        // ===============================
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            var service = factory.CreateOrganizationService(null);
            var tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            try
            {
                using (var http = new HttpClient())
                {
                    http.DefaultRequestHeaders.Authorization =
                        new AuthenticationHeaderValue("AccessKey", AccessKey);

                    string dateStart = DateTime.UtcNow.AddHours(-16)
                        .ToString("yyyy-MM-ddTHH:mm:ssZ");

                    var jsonResponse = http.GetStringAsync(
                        "https://carolinahandling.hiveqr.com/provider/inventories/transaction/last-locations?dateStart=" + dateStart
                    ).Result;

                    var results = JArray.Parse(jsonResponse);

                    var responseList = new List<JObject>();

                    var locationBatch = new ExecuteMultipleRequest
                    {
                        Settings = new ExecuteMultipleSettings
                        {
                            ContinueOnError = true,
                            ReturnResponses = EnableDiagnostics
                        },
                        Requests = new OrganizationRequestCollection()
                    };

                    var equipmentBatch = new ExecuteMultipleRequest
                    {
                        Settings = new ExecuteMultipleSettings
                        {
                            ContinueOnError = true,
                            ReturnResponses = false
                        },
                        Requests = new OrganizationRequestCollection()
                    };

                    foreach (var row in results)
                    {
                        var serial = Normalize((string)row["serialNumber"]);
                        if (string.IsNullOrWhiteSpace(serial)) continue;

                        var incomingLoc = Normalize((string)row["locationId"]);
                        if (string.IsNullOrWhiteSpace(incomingLoc)) continue;

                        DateTime? timestamp = null;
                        if (DateTime.TryParse(
                            (string)row["timestamp"],
                            CultureInfo.InvariantCulture,
                            DateTimeStyles.AdjustToUniversal,
                            out var parsed))
                        {
                            timestamp = parsed;
                        }

                        string branchCity = null;
                        string branchName = null;

                        if (row["branch"] is JObject b)
                        {
                            branchCity = (string)b["city"];
                            branchName = (string)b["name"];
                        }

                        var facilityCode = PickFacilityCode(branchCity, branchName);

                        // ===============================
                        // UPSERT ch_lastlocation
                        // ===============================
                        var existing = service.RetrieveMultiple(new QueryExpression("ch_lastlocation")
                        {
                            ColumnSet = new ColumnSet("ch_location"),
                            Criteria =
                            {
                                Conditions =
                                {
                                    new ConditionExpression("ch_serialnumber", ConditionOperator.Equal, serial)
                                }
                            }
                        }).Entities.FirstOrDefault();

                        bool wasCreated = existing == null;
                        bool needsUpdate =
                            wasCreated ||
                            Normalize(existing.GetAttributeValue<string>("ch_location")) != incomingLoc;

                        bool wasUpdated = !wasCreated && needsUpdate;

                        if (needsUpdate)
                        {
                            var entity = new Entity("ch_lastlocation", existing != null ? existing.Id : Guid.Empty);

                            if (wasCreated)
                            {
                                entity["ch_name"] = serial;
                                entity["ch_serialnumber"] = serial;
                            }

                            entity["ch_location"] = incomingLoc;

                            if (timestamp != null)
                                entity["ch_lastupdated"] = timestamp;

                            entity["ch_branchname"] = branchName;
                            entity["ch_branchcity"] = branchCity;

                            locationBatch.Requests.Add(
                                wasCreated
                                    ? (OrganizationRequest)new CreateRequest { Target = entity }
                                    : new UpdateRequest { Target = entity }
                            );
                        }

                        // ===============================
                        // Unified equipment
                        // ===============================
                        var qe = new QueryExpression("ch_unifiedequipment")
                        {
                            ColumnSet = new ColumnSet(
                                "ch_truckserial", "ch_trucklocation", "ch_truckfacility",
                                "ch_battery1serial", "ch_battery1location", "ch_battery1facility",
                                "ch_battery2serial", "ch_battery2location", "ch_battery2facility",
                                "ch_attachment1serial", "ch_attachment1location", "ch_attachment1facility",
                                "ch_attachment2serial", "ch_attachment2location", "ch_attachment2facility",
                                "ch_charger1serial", "ch_charger1location", "ch_charger1facility",
                                "ch_charger2serial", "ch_charger2location", "ch_charger2facility"
                            ),
                            Criteria =
                            {
                                FilterOperator = LogicalOperator.Or,
                                Conditions =
                                {
                                    new ConditionExpression("ch_truckserial", ConditionOperator.Equal, serial),
                                    new ConditionExpression("ch_battery1serial", ConditionOperator.Equal, serial),
                                    new ConditionExpression("ch_battery2serial", ConditionOperator.Equal, serial),
                                    new ConditionExpression("ch_attachment1serial", ConditionOperator.Equal, serial),
                                    new ConditionExpression("ch_attachment2serial", ConditionOperator.Equal, serial),
                                    new ConditionExpression("ch_charger1serial", ConditionOperator.Equal, serial),
                                    new ConditionExpression("ch_charger2serial", ConditionOperator.Equal, serial)
                                }
                            }
                        };

                        foreach (var eq in service.RetrieveMultiple(qe).Entities)
                        {
                            var update = new Entity("ch_unifiedequipment", eq.Id);
                            bool changed = false;

                            Action<string, string, string> apply = (serialField, locField, facField) =>
                            {
                                if (Normalize(eq.GetAttributeValue<string>(serialField)) != serial)
                                    return;

                                update[locField] = incomingLoc;
                                changed = true;

                                if (!string.IsNullOrWhiteSpace(facilityCode))
                                {
                                    var opt = GetFacilityOptionValue(service, facField, facilityCode);
                                    if (opt.HasValue &&
                                        eq.GetAttributeValue<OptionSetValue>(facField)?.Value != opt.Value)
                                    {
                                        update[facField] = new OptionSetValue(opt.Value);
                                    }
                                }
                            };

                            apply("ch_truckserial", "ch_trucklocation", "ch_truckfacility");
                            apply("ch_battery1serial", "ch_battery1location", "ch_battery1facility");
                            apply("ch_battery2serial", "ch_battery2location", "ch_battery2facility");
                            apply("ch_attachment1serial", "ch_attachment1location", "ch_attachment1facility");
                            apply("ch_attachment2serial", "ch_attachment2location", "ch_attachment2facility");
                            apply("ch_charger1serial", "ch_charger1location", "ch_charger1facility");
                            apply("ch_charger2serial", "ch_charger2location", "ch_charger2facility");

                            if (changed)
                                equipmentBatch.Requests.Add(new UpdateRequest { Target = update });
                        }

                        // ===============================
                        // RESULT JSON
                        // ===============================
                        responseList.Add(new JObject
                        {
                            ["serialNumber"] = serial,
                            ["locationId"] = incomingLoc,
                            ["timestamp"] = timestamp?.ToString("MM/dd/yyyy HH:mm:ss")
                                ?? DateTime.UtcNow.ToString("MM/dd/yyyy HH:mm:ss"),
                            ["wasCreated"] = wasCreated,
                            ["wasUpdated"] = wasUpdated
                        });

                        if (locationBatch.Requests.Count >= 50)
                        {
                            service.Execute(locationBatch);
                            locationBatch.Requests.Clear();
                        }

                        if (equipmentBatch.Requests.Count >= 100)
                        {
                            service.Execute(equipmentBatch);
                            equipmentBatch.Requests.Clear();
                        }
                    }

                    if (locationBatch.Requests.Count > 0)
                        service.Execute(locationBatch);

                    if (equipmentBatch.Requests.Count > 0)
                        service.Execute(equipmentBatch);

                    context.OutputParameters["ResultsJson"] =
                        JArray.FromObject(responseList).ToString();
                }
            }
            catch (Exception ex)
            {
                tracing.Trace("SyncLastLocation ERROR: {0}", ex.ToString());
                throw new InvalidPluginExecutionException(
                    "SyncLastLocation failed: " + ex.Message, ex);
            }
        }
    }
}
