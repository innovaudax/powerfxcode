﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace rooks.Plugins
{
    /// <summary>
    /// Custom API plugin: rooks_GetRedtailHouseholds
    ///
    /// Given a Redtail contacts/search JSON payload, pairs individuals into
    /// households by mutual spouse_name <-> full_name match, then checks each
    /// household against the rooks_household table to flag existing ones.
    ///
    /// Output shape (JSON string):
    /// [
    ///   {
    ///     "primaryid": "9309",
    ///     "secondaryid": "10130",
    ///     "householdname": "McSample, Samuel and Samantha",
    ///     "existinroadmap": true,
    ///     "members": [
    ///       { "id": 9309, "full_name": "...", "first_name": "...", "last_name": "..." },
    ///       { "id": 10130, "full_name": "...", "first_name": "...", "last_name": "..." }
    ///     ]
    ///   }
    /// ]
    ///
    /// Rules:
    ///   - Pairing requires MUTUAL spouse_name <-> full_name match (case-insensitive, trimmed).
    ///   - Unpaired contacts become solo households (secondaryid empty, one member).
    ///   - Lower Redtail id is primary.
    ///   - existinroadmap = true if primaryid OR secondaryid matches the
    ///     rooks_redtailidentifier column on any rooks_household row.
    ///   - If matched, householdname comes from the existing rooks_householdname;
    ///     otherwise we synthesize "Lastname, First1 and First2" (or just "Lastname, First" for solo).
    ///   - All individuals are included (no status/type filter).
    ///
    /// Inputs:
    ///   RedtailPayload (string, required) - JSON; accepts the full flow HTTP response,
    ///                                       a body object with "contacts", or a bare array.
    ///
    /// Outputs:
    ///   Households (string) - JSON array of household objects.
    ///   Count      (int)    - Number of households returned.
    /// </summary>
    public class GetRedtailHouseholdsPlugin : IPlugin
    {
        // Roadmap target table & columns. Change here if the schema ever moves.
        private const string RoadmapTable = "rooks_household";
        private const string RoadmapRedtailIdColumn = "rooks_redtailidentifier";
        private const string RoadmapHouseholdNameColumn = "rooks_householdname";

        public void Execute(IServiceProvider serviceProvider)
        {
            var tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            var service = factory.CreateOrganizationService(context.UserId);

            try
            {
                tracing.Trace("GetRedtailHouseholds: starting.");

                // ---- 1. Read input payload ----
                if (!context.InputParameters.Contains("RedtailPayload") ||
                    !(context.InputParameters["RedtailPayload"] is string payload) ||
                    string.IsNullOrWhiteSpace(payload))
                {
                    throw new InvalidPluginExecutionException(
                        "Required input parameter 'RedtailPayload' (string JSON) is missing or empty.");
                }
                tracing.Trace("Received payload of {0} chars.", payload.Length);

                // ---- 2. Parse Redtail contacts ----
                List<RedtailContact> contacts = ParseRedtailContacts(payload, tracing);
                tracing.Trace("Parsed {0} total contacts.", contacts.Count);

                // ---- 3. Pair into households ----
                List<HouseholdBuild> households = BuildHouseholds(contacts, tracing);
                tracing.Trace("Built {0} households.", households.Count);

                // ---- 4. Cross-check against rooks_household ----
                var roadmapRows = LoadRoadmapHouseholds(service, tracing);
                tracing.Trace("Loaded {0} rooks_household rows.", roadmapRows.Count);

                // ---- 5. Project final output ----
                var output = new List<HouseholdOutput>(households.Count);
                foreach (var h in households)
                {
                    string primary = h.Primary.Id;
                    string secondary = h.Secondary != null ? h.Secondary.Id : string.Empty;

                    RoadmapRow match = FindRoadmapMatch(roadmapRows, primary, secondary);
                    bool exists = match != null;
                    string name = exists && !string.IsNullOrWhiteSpace(match.HouseholdName)
                        ? match.HouseholdName
                        : SynthesizeHouseholdName(h);

                    output.Add(new HouseholdOutput
                    {
                        primaryid = primary,
                        secondaryid = secondary,
                        householdname = name,
                        existinroadmap = exists,
                        members = BuildMemberList(h)
                    });
                }

                context.OutputParameters["Households"] = SerializeOutput(output);
                context.OutputParameters["Count"] = output.Count;
                tracing.Trace("Returning {0} households.", output.Count);
            }
            catch (InvalidPluginExecutionException)
            {
                throw;
            }
            catch (Exception ex)
            {
                tracing.Trace("Unhandled exception: {0}", ex.ToString());
                throw new InvalidPluginExecutionException(
                    "GetRedtailHouseholds failed: " + ex.Message, ex);
            }
        }

        // =================================================================
        // Pairing logic
        // =================================================================
        private class HouseholdBuild
        {
            public RedtailContact Primary;
            public RedtailContact Secondary; // null for solo
        }

        private static List<HouseholdBuild> BuildHouseholds(List<RedtailContact> contacts, ITracingService tracing)
        {
            // Index by id (string) for spouse resolution after we match by name.
            // Index by normalized full_name for spouse_name lookup.
            var byFullName = new Dictionary<string, RedtailContact>(StringComparer.OrdinalIgnoreCase);
            foreach (var c in contacts)
            {
                if (string.IsNullOrWhiteSpace(c.FullName)) continue;
                string key = c.FullName.Trim();
                // If duplicate full_names exist, first one wins; a name collision can't
                // be resolved without more info, and mutual-match logic below will
                // still reject bogus pairings.
                if (!byFullName.ContainsKey(key)) byFullName[key] = c;
            }

            var paired = new HashSet<string>(StringComparer.OrdinalIgnoreCase); // contact ids already placed
            var households = new List<HouseholdBuild>();

            foreach (var c in contacts)
            {
                if (string.IsNullOrEmpty(c.Id)) continue;
                if (paired.Contains(c.Id)) continue;

                RedtailContact spouse = null;
                if (!string.IsNullOrWhiteSpace(c.SpouseName))
                {
                    string spouseKey = c.SpouseName.Trim();
                    if (byFullName.TryGetValue(spouseKey, out var candidate) &&
                        candidate != null &&
                        !string.IsNullOrEmpty(candidate.Id) &&
                        !string.Equals(candidate.Id, c.Id, StringComparison.OrdinalIgnoreCase) &&
                        !paired.Contains(candidate.Id))
                    {
                        // Mutual check: candidate's spouse_name must point back to c.
                        if (!string.IsNullOrWhiteSpace(candidate.SpouseName) &&
                            !string.IsNullOrWhiteSpace(c.FullName) &&
                            string.Equals(candidate.SpouseName.Trim(), c.FullName.Trim(), StringComparison.OrdinalIgnoreCase))
                        {
                            spouse = candidate;
                        }
                        else
                        {
                            tracing.Trace("Spouse name matched but not mutual for id={0} (spouse_name='{1}').",
                                c.Id, c.SpouseName);
                        }
                    }
                }

                var hh = new HouseholdBuild { Primary = c, Secondary = spouse };
                if (spouse != null)
                {
                    // Lower id = primary.
                    if (CompareIdsNumeric(spouse.Id, c.Id) < 0)
                    {
                        hh.Primary = spouse;
                        hh.Secondary = c;
                    }
                    paired.Add(spouse.Id);
                }
                paired.Add(c.Id);
                households.Add(hh);
            }

            return households;
        }

        /// <summary>
        /// Compares two Redtail ids as integers when possible, falling back to string compare.
        /// Returns &lt;0 if a&lt;b, 0 if equal, &gt;0 if a&gt;b.
        /// </summary>
        private static int CompareIdsNumeric(string a, string b)
        {
            long la, lb;
            bool aOk = long.TryParse(a, out la);
            bool bOk = long.TryParse(b, out lb);
            if (aOk && bOk) return la.CompareTo(lb);
            return string.Compare(a, b, StringComparison.OrdinalIgnoreCase);
        }

        private static string SynthesizeHouseholdName(HouseholdBuild h)
        {
            var p = h.Primary;
            if (h.Secondary == null)
            {
                // Solo: "Lastname, Firstname"
                string last = (p.LastName ?? string.Empty).Trim();
                string first = (p.FirstName ?? string.Empty).Trim();
                if (last.Length == 0 && first.Length == 0)
                    return p.FullName ?? string.Empty;
                if (last.Length == 0) return first;
                if (first.Length == 0) return last;
                return last + ", " + first;
            }

            var s = h.Secondary;
            string pLast = (p.LastName ?? string.Empty).Trim();
            string sLast = (s.LastName ?? string.Empty).Trim();
            string pFirst = (p.FirstName ?? string.Empty).Trim();
            string sFirst = (s.FirstName ?? string.Empty).Trim();

            // Same last name: "Smith, John and Jane"
            if (!string.IsNullOrEmpty(pLast) &&
                string.Equals(pLast, sLast, StringComparison.OrdinalIgnoreCase))
            {
                return pLast + ", " + pFirst + " and " + sFirst;
            }
            // Different last names: "Smith, John and Jones, Jane"
            return (pLast + ", " + pFirst).TrimEnd(',', ' ') +
                   " and " +
                   (sLast + ", " + sFirst).TrimEnd(',', ' ');
        }

        private static List<MemberOutput> BuildMemberList(HouseholdBuild h)
        {
            var list = new List<MemberOutput> { ToMember(h.Primary) };
            if (h.Secondary != null) list.Add(ToMember(h.Secondary));
            return list;
        }

        private static MemberOutput ToMember(RedtailContact c)
        {
            long idNum;
            long.TryParse(c.Id ?? string.Empty, out idNum);
            return new MemberOutput
            {
                id = idNum,
                full_name = c.FullName ?? string.Empty,
                first_name = c.FirstName ?? string.Empty,
                last_name = c.LastName ?? string.Empty
            };
        }

        // =================================================================
        // Roadmap lookup
        // =================================================================
        private class RoadmapRow
        {
            public string RedtailId;
            public string HouseholdName;
        }

        /// <summary>
        /// Load rooks_household rows indexed by rooks_redtailidentifier.
        /// If duplicate identifiers exist, first one wins.
        /// </summary>
        private static Dictionary<string, RoadmapRow> LoadRoadmapHouseholds(
            IOrganizationService service, ITracingService tracing)
        {
            var index = new Dictionary<string, RoadmapRow>(StringComparer.OrdinalIgnoreCase);
            var query = new QueryExpression(RoadmapTable)
            {
                ColumnSet = new ColumnSet(RoadmapRedtailIdColumn, RoadmapHouseholdNameColumn),
                PageInfo = new PagingInfo { Count = 5000, PageNumber = 1 },
                NoLock = true
            };
            query.Criteria.AddCondition(RoadmapRedtailIdColumn, ConditionOperator.NotNull);

            while (true)
            {
                var page = service.RetrieveMultiple(query);
                foreach (var e in page.Entities)
                {
                    string id = SafeString(e, RoadmapRedtailIdColumn);
                    if (string.IsNullOrEmpty(id)) continue;
                    if (index.ContainsKey(id)) continue;
                    index[id] = new RoadmapRow
                    {
                        RedtailId = id,
                        HouseholdName = SafeString(e, RoadmapHouseholdNameColumn),
                    };
                }
                if (!page.MoreRecords) break;
                query.PageInfo.PageNumber++;
                query.PageInfo.PagingCookie = page.PagingCookie;
            }
            return index;
        }

        private static string SafeString(Entity e, string col)
        {
            if (!e.Contains(col) || e[col] == null) return string.Empty;
            return e[col].ToString().Trim();
        }

        /// <summary>
        /// Match if primaryid or secondaryid appears in the rooks_redtailidentifier index.
        /// Primary is checked first, so if both sides happen to be in roadmap under
        /// different rows, the primary's row wins for householdname.
        /// </summary>
        private static RoadmapRow FindRoadmapMatch(
            Dictionary<string, RoadmapRow> index, string primary, string secondary)
        {
            if (!string.IsNullOrEmpty(primary) && index.TryGetValue(primary, out var rp)) return rp;
            if (!string.IsNullOrEmpty(secondary) && index.TryGetValue(secondary, out var rs)) return rs;
            return null;
        }

        // =================================================================
        // JSON parsing
        // =================================================================
        [DataContract]
        private class FlowHttpResponseShape
        {
            [DataMember(Name = "body")]
            public RedtailContactsResponse Body { get; set; }
        }

        [DataContract]
        private class RedtailContactsResponse
        {
            [DataMember(Name = "contacts")]
            public List<RedtailContact> Contacts { get; set; }
        }

        [DataContract]
        private class RedtailContact
        {
            [DataMember(Name = "id")]
            public object IdRaw { get; set; }
            public string Id { get { return IdRaw == null ? null : IdRaw.ToString(); } }

            [DataMember(Name = "first_name")]
            public string FirstName { get; set; }

            [DataMember(Name = "last_name")]
            public string LastName { get; set; }

            [DataMember(Name = "full_name")]
            public string FullName { get; set; }

            [DataMember(Name = "spouse_name")]
            public string SpouseName { get; set; }

            [DataMember(Name = "type")]
            public string Type { get; set; }

            [DataMember(Name = "status_id")]
            public object StatusId { get; set; }
        }

        private static List<RedtailContact> ParseRedtailContacts(string json, ITracingService tracing)
        {
            if (string.IsNullOrWhiteSpace(json)) return new List<RedtailContact>();

            // Shape: full flow HTTP response { "body": { "contacts": [...] } }
            try
            {
                using (var ms = new MemoryStream(Encoding.UTF8.GetBytes(json)))
                {
                    var ser = new DataContractJsonSerializer(typeof(FlowHttpResponseShape));
                    var wrapper = (FlowHttpResponseShape)ser.ReadObject(ms);
                    if (wrapper != null && wrapper.Body != null && wrapper.Body.Contacts != null && wrapper.Body.Contacts.Count > 0)
                    {
                        tracing.Trace("Parsed payload as full flow HTTP response wrapper.");
                        return wrapper.Body.Contacts;
                    }
                }
            }
            catch (Exception ex)
            {
                tracing.Trace("Flow-wrapper parse didn't apply: {0}", ex.Message);
            }

            // Shape: { "contacts": [...] }
            try
            {
                using (var ms = new MemoryStream(Encoding.UTF8.GetBytes(json)))
                {
                    var ser = new DataContractJsonSerializer(typeof(RedtailContactsResponse));
                    var resp = (RedtailContactsResponse)ser.ReadObject(ms);
                    if (resp != null && resp.Contacts != null)
                    {
                        tracing.Trace("Parsed payload as Redtail body object.");
                        return resp.Contacts;
                    }
                }
            }
            catch (Exception ex)
            {
                tracing.Trace("Body-object parse didn't apply, trying bare array: {0}", ex.Message);
            }

            // Shape: bare array
            try
            {
                using (var ms = new MemoryStream(Encoding.UTF8.GetBytes(json)))
                {
                    var ser = new DataContractJsonSerializer(typeof(List<RedtailContact>));
                    var list = (List<RedtailContact>)ser.ReadObject(ms);
                    tracing.Trace("Parsed payload as bare contacts array.");
                    return list ?? new List<RedtailContact>();
                }
            }
            catch (Exception ex)
            {
                tracing.Trace("Bare-array parse failed: {0}", ex.Message);
                throw new InvalidPluginExecutionException(
                    "Could not parse RedtailPayload JSON.");
            }
        }

        // =================================================================
        // Output serialization
        // =================================================================
        [DataContract]
        private class HouseholdOutput
        {
            [DataMember(Name = "primaryid", Order = 1)]
            public string primaryid { get; set; }
            [DataMember(Name = "secondaryid", Order = 2)]
            public string secondaryid { get; set; }
            [DataMember(Name = "householdname", Order = 3)]
            public string householdname { get; set; }
            [DataMember(Name = "existinroadmap", Order = 4)]
            public bool existinroadmap { get; set; }
            [DataMember(Name = "members", Order = 5)]
            public List<MemberOutput> members { get; set; }
        }

        [DataContract]
        private class MemberOutput
        {
            [DataMember(Name = "id", Order = 1)]
            public long id { get; set; }
            [DataMember(Name = "full_name", Order = 2)]
            public string full_name { get; set; }
            [DataMember(Name = "first_name", Order = 3)]
            public string first_name { get; set; }
            [DataMember(Name = "last_name", Order = 4)]
            public string last_name { get; set; }
        }

        private static string SerializeOutput(List<HouseholdOutput> list)
        {
            using (var ms = new MemoryStream())
            {
                var ser = new DataContractJsonSerializer(typeof(List<HouseholdOutput>));
                ser.WriteObject(ms, list);
                return Encoding.UTF8.GetString(ms.ToArray());
            }
        }
    }
}