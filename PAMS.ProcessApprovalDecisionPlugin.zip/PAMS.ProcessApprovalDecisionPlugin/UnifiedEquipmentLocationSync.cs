﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CarolinaHandling.Dataverse.Plugins
{
    /// <summary>
    /// Pre-Operation plugin on ch_unifiedequipment (Create + Update).
    /// If a serial field is present/changed, calls Custom API ivx_HTTPCaller to get locationId and sets the corresponding location field.
    /// </summary>
    public class UnifiedEquipmentLocationSync : IPlugin
    {
        private static readonly (string Serial, string Location)[] Pairs = new[] {
            ("ch_truckserial",        "ch_trucklocation"),
            ("ch_battery1serial",     "ch_battery1location"),
            ("ch_battery2serial",     "ch_battery2location"),
            ("ch_attachment1serial",  "ch_attachment1location"),
            ("ch_attachment2serial",  "ch_attachment2location"),
            ("ch_charger1serial",     "ch_charger1location"),
            ("ch_charger2serial",     "ch_charger2location"),
        };

        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            var factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            var service = factory.CreateOrganizationService(context.UserId);

            if (!context.InputParameters.Contains("Target") || !(context.InputParameters["Target"] is Entity target))
                return;
            if (!string.Equals(target.LogicalName, "ch_unifiedequipment", StringComparison.OrdinalIgnoreCase))
                return;

            foreach (var (serialAttr, locAttr) in Pairs)
            {
                // Only attempt when serial attribute is present in Target (changed) or on Create when provided
                var hasSerial = target.Attributes.Contains(serialAttr);
                var serialVal = hasSerial ? (target.GetAttributeValue<string>(serialAttr) ?? "").Trim() : null;
                if (string.IsNullOrWhiteSpace(serialVal)) continue;

                try
                {
                    var locationId = LookupLocationIdViaCustomApi(service, serialVal, tracing);
                    if (!string.IsNullOrWhiteSpace(locationId))
                    {
                        target[locAttr] = locationId;
                    }
                }
                catch (Exception ex)
                {
                    tracing.Trace($"LocationSync error for {serialAttr}: {ex}");
                    // Do not fail the transaction unless the requirement is strict; you can choose to throw.
                    // throw new InvalidPluginExecutionException("Failed to fetch location", ex);
                }
            }
        }

        private static string LookupLocationIdViaCustomApi(IOrganizationService service, string serial, ITracingService tracing)
        {
            var url = $"https://carolinahandling.hiveqr.com/provider/inventories/transaction/last-locations?serialNumber={Uri.EscapeDataString(serial)}";

            var headers = new Dictionary<string, string> {
    {"Authorization", "AccessKey EOeqHUxEH4TgZhpf9S7brQ874GRAWsYn"}
};

            // Build an OrganizationRequest to call your Custom API (ivx_HTTPCaller)
            var req = new OrganizationRequest("ivx_HTTPCaller")
            {
                ["Method"] = "GET",
                ["Url"] = url,
                // Use ApiKey mode so the handler sets header AccessKey automatically (per your code)
                ["AuthType"] = "",
                ["AuthValue"] = "",
                // Optional: additional headers can be provided as JSON dictionary string if needed
                ["HeadersJson"] = JsonConvert.SerializeObject(headers),
                // Timeouts, body, etc. are optional for GET
                ["TimeoutSeconds"] = 30
            }; 
        

            var res = service.Execute(req); // returns OrganizationResponse with output params from your handler

            // Extract your Custom API outputs
            var statusCode = res.Results.Contains("StatusCode") ? (int)res.Results["StatusCode"] : -1;
            var responseBody = res.Results.Contains("ResponseBody") ? res.Results["ResponseBody"] as string : null;
            var errorMessage = res.Results.Contains("ErrorMessage") ? res.Results["ErrorMessage"] as string : null;

            if (statusCode != 200 || string.IsNullOrEmpty(responseBody))
            {
                tracing.Trace($"HTTPCaller non-200 or empty body: status={statusCode}, err={errorMessage}");
                return null;
            }

            // ResponseBody is a stringified JSON array; pick first.locationId
            try
            {
                var arr = JArray.Parse(responseBody);
                var first = arr.FirstOrDefault() as JObject;
                var locationId = first?["locationId"]?.ToString();
                return string.IsNullOrWhiteSpace(locationId) ? null : locationId;
            }
            catch (Exception ex)
            {
                tracing.Trace($"JSON parse error: {ex}");
                return null;
            }
        }

    }
}
