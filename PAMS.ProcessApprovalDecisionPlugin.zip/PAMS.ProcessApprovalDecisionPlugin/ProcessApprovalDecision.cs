﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.IO;
using System.Text;
using System.ServiceModel;

namespace Pams.Plugins
{
    /// <summary>
    /// Processes an approval decision on the current step of a project request.
    /// Runs with elevated privilege so a Read-only approver can record a decision without
    /// direct Write access to the request (capability comes from being the current step's
    /// approver in the chain, not from record-level Write).
    ///
    /// Custom API: pams_ProcessApprovalDecision
    /// Inputs:
    ///   RequestId    (String)  - pams_projectrequest id
    ///   Decision     (String)  - "Approve" | "Reject" | "RequestChanges" | "Cancel" | "Reassign"
    ///   Comment      (String)  - required for Reject / RequestChanges (req 99.2.1)
    ///   OnBehalf     (Boolean) - optional; admin acting on behalf (req 33.1, comment required)
    ///   Step         (Integer) - Reassign only: the chain step to reassign
    ///   NewApproverId(String)  - Reassign only: systemuser id of the new approver
    /// Outputs:
    ///   NewStatus (String), CurrentStep (Integer), Message (String)
    ///   ChainJson (String) - set on Reassign so the form can sync its in-memory chain
    ///
    /// Decision behavior (requirements):
    ///  - Approve: mark current step approved; if last step -> Approved (req 86); else advance
    ///    to the next step (the ApproverSharingPlugin then shares/notifies the new approver).
    ///  - Reject (req 91): status Rejected, Assigned To blank, editable. Resubmit restarts at
    ///    step 1 (handled by the chain-builder on next submit).
    ///  - RequestChanges (req 90): status Changes Requested, Assigned To -> Project Manager,
    ///    editable. Resubmit restarts at step 1.
    ///  - Cancel (req 93): status Cancelled, editable; resubmit restarts at step 1.
    ///  - Reassign (req 33): admin changes an un-acted step's approver mid-flight; rebuilds the
    ///    card (if the current step changed), ensures the new approver as a watcher, posts a note.
    ///  - Comment required for Reject / RequestChanges (req 99.2.1).
    ///
    /// On each advance (and on Reassign of the current step), the resolved approval Adaptive
    /// Card for the current approver is built and stored on pams_adaptivecardjson in the SAME
    /// update (see BuildCard). The Power Automate flow reads that field and sends it verbatim -
    /// no @{...} substitution.
    ///
    /// The "Open in PAMS" deep-link org base url is read from the pams_OrgBaseUrl environment
    /// variable at runtime (no hardcoded org url). If unset, the deep link is omitted.
    ///
    /// Authority: caller must be the current step's approver, OR an Other Valid Approver of
    /// that step (req 77.8.3), OR an admin acting OnBehalf (req 33.1; comment required).
    /// Reassign is admin-only (mirrors the request form's pencil gating).
    /// </summary>
    public sealed class ProcessApprovalDecisionPlugin : IPlugin
    {
        private const string EntityRequest = "pams_projectrequest";
        // Web API entity SET name (plural) - needed for the file-download URLs in emails.
        private const string EntitySetRequest = "pams_projectrequests";

        // Morton logo as a base64 data-URI for adaptive cards (renderer can't fetch the authenticated
        // web resource). PASTE the full "data:image/...;base64,...." string of pams_mortonLogo here.
        private const string LogoDataUri = "";
        private const string EntityWatcher = "pams_requestwatcher";     // watcher table (Reassign)
        // pams_watchersource - PROVENANCE of a watcher row (global choice).
        // Distinct from pams_ismanual, which is the REMOVABILITY flag req 52 keys on. A row can be
        // un-removable AND have come from the chain; conflating the two is what made it impossible
        // to tell a stale approver row from a deliberate one.
        // pams_accesslevel - see the note in ApprovalChainBuilderPlugin. Kept in step here.
        private const int AccessLevelNone = 1;
        private const int AccessLevelRead = 2;
        private const int AccessLevelWrite = 3;
        // Distinct from None on purpose. None = "no access" generically (a cancelled request -
        // dead for everyone). Revoked = "was in the approval workflow and is not any more", which
        // is a statement about the CHAIN, not about the request. Keeping them apart means the
        // watcher list can explain WHY someone lost access, and req 52's ban on deleting
        // system-added rows stops being a problem - the row survives and says what happened.
        private const int AccessLevelRevoked = 4;

        private const int WatcherSourceManual = 1;
        private const int WatcherSourceApprover = 2;
        private const int WatcherSourceSystem = 3;
        private const string FieldChainJson = "pams_approvalchainjson";
        private const string FieldCurrentStep = "pams_currentstagesequence";
        private const string FieldCurrentRule = "pams_currentapprovalstep";   // lookup -> pams_approvalrules
        private const string RuleEntity = "pams_approvalrules";
        private const string FieldStatus = "pams_approvalstatus";
        private const string FieldAssignedTo = "pams_assignedtoid";     // lookup -> systemuser (PM)
        private const string FieldReturnSnapshot = "pams_returnsnapshot"; // JSON of values as of a return
        private const string FieldSupplemental = "pams_supplemental";       // two-option: is this a supplemental?
        private const string FieldOriginalRequest = "pams_originalprojectrequest"; // self-lookup to the original
        private const string FieldCreatedBy = "createdby"; // request creator = PM (req 90)

        // ---- card fields (CONFIRM each against your schema) ----
        private const string FieldCardJson = "pams_adaptivecardjson";
        private const string FieldTitle = "pams_projecttitle";                 // CONFIRM
        private const string FieldIdentifier = "pams_projectrequestidentifier";     // CONFIRM
        private const string FieldSubmissionDt = "pams_submissiondate";
        private const string FieldProjectType = "pams_projecttypeid";                // lookup
        private const string FieldProjectNumber = "pams_projectnumber";              // text (stamped at setup)
        private const string FieldProjectManager = "pams_projectmanager";            // lookup -> systemuser
        private const string FieldLocation = "pams_locationid";                   // lookup
        private const string FieldWorkflowLabel = "pams_appliedworkflowlabel";
        // Frozen-USD amount. Matches the chain-builder's pams_usdtotalauthorized, with a
        // fallback to the entered total. (CONFIRM these are your real field names.)
        private const string FieldUsdAmount = "pams_usdtotalauthorized";          // CONFIRM
        private const string FieldBaseAmount = "pams_totalauthorized";             // CONFIRM

        // Org base url for the "Open in PAMS" deep link is read from this environment
        // variable at runtime (per-environment, solution-portable). Set its current value
        // to e.g. https://mscsbdev.crm.dynamics.com (no trailing slash). CONFIRM the schema
        // name matches your publisher prefix.
        private const string EnvVarOrgUrl = "pams_OrgBaseUrl";

        // HTTPS endpoint the emailed card's Action.Http buttons POST to (the flow HTTP-trigger
        // or function that validates Outlook's bearer token and calls this same action).
        // Read from an environment variable so it's per-environment. If unset, the card falls
        // back to Action.Submit (works only in flow-mediated / Teams contexts, not raw email).
        private const string EnvVarActionUrl = "pams_ApprovalActionUrl";

        // Actionable Message originator GUID (from the Actionable Email Developer Dashboard).
        // Emitted at the card root as "originator" so Outlook trusts the Action.Http buttons.
        // If unset, no originator is emitted (buttons render read-only until registered).
        private const string EnvVarOriginator = "pams_AmOriginator";

        // Base URL of the flow that records a decision from an emailed OpenUrl LINK (GET-style,
        // decision carried in the query string). Because it's an Action.OpenUrl (not Action.Http),
        // it always renders in Outlook with no actionable-message registration required. The flow
        // reads requestId/decision/step/approverId from the query string; for Reject/RequestChanges
        // it returns an HTML page that collects the required comment before acting. If unset, the
        // decision buttons are omitted and only "Open in PAMS" is shown.
        private const string EnvVarDecisionLink = "pams_ApprovalLinkUrl";
        // The model-driven app's UNIQUE name (stable across environments, unlike the app id which
        // is per-environment). We resolve the app id at runtime from the appmodule table by this
        // name, so nothing needs re-setting per deploy.
        private const string AppUniqueName = "pams_PAMSApprovalManagement";

        private const int StatusPending = 282150000;
        private const int StatusApproved = 282150001;
        private const int StatusRejected = 282150002;
        private const int StatusChanges = 282150003;
        private const int StatusCancelled = 282150004;
        private const int StatusPendingProjectSetup = 282150006; // Approved - Pending Project Setup
        private const int StatusProjectSetupComplete = 282150007; // Approved - Project Setup Complete

        private const string AdminTeamName = "PAMS - Administrators";

        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            var factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            // Run ELEVATED (null = SYSTEM) so a Read-only approver can record a decision without
            // Write on the request. Authority is verified separately via context.InitiatingUserId.
            var service = factory.CreateOrganizationService(null);

            try
            {
                string requestIdStr = In<string>(context, "RequestId");
                string decision = (In<string>(context, "Decision") ?? "").Trim();
                string comment = In<string>(context, "Comment") ?? "";
                bool onBehalf = In<bool>(context, "OnBehalf");
                // Reassign-only inputs (ignored by the other decisions).
                int reassignStep = In<int>(context, "Step");
                string newApproverIdStr = In<string>(context, "NewApproverId");

                if (!Guid.TryParse(requestIdStr, out Guid requestId))
                    throw new InvalidPluginExecutionException("RequestId is not a valid GUID.");

                bool isReject = decision.Equals("Reject", StringComparison.OrdinalIgnoreCase);
                bool isChanges = decision.Equals("RequestChanges", StringComparison.OrdinalIgnoreCase);
                bool isApprove = decision.Equals("Approve", StringComparison.OrdinalIgnoreCase);
                bool isCancel = decision.Equals("Cancel", StringComparison.OrdinalIgnoreCase);
                bool isCompleteSetup = decision.Equals("CompleteSetup", StringComparison.OrdinalIgnoreCase);
                bool isReassign = decision.Equals("Reassign", StringComparison.OrdinalIgnoreCase);
                if (!isApprove && !isReject && !isChanges && !isCancel && !isReassign && !isCompleteSetup)
                    throw new InvalidPluginExecutionException("Decision must be Approve, Reject, RequestChanges, Cancel, Reassign, or CompleteSetup.");

                // Comment required for Reject / RequestChanges (req 99.2.1) and any on-behalf action
                // (req 33.1 / 93.2.2 - admin cancelling on behalf requires a comment).
                if ((isReject || isChanges || onBehalf) && string.IsNullOrWhiteSpace(comment))
                    throw new InvalidPluginExecutionException("A comment is required for this action.");

                // Retrieve decision fields + the card display fields in one shot, so the
                // advance / reassign branches can build the card without a second retrieve.
                var req = service.Retrieve(EntityRequest, requestId,
                    new ColumnSet(
                        FieldChainJson, FieldCurrentStep, FieldStatus, FieldCreatedBy,
                        FieldTitle, FieldIdentifier, FieldSubmissionDt, FieldProjectType,
                        FieldProjectNumber, FieldProjectManager,
                        FieldLocation, FieldWorkflowLabel,
                        FieldUsdAmount, FieldBaseAmount));

                int statusVal = (req.GetAttributeValue<OptionSetValue>(FieldStatus) ?? new OptionSetValue(0)).Value;

                // Read the pointer + chain json up front so all branches (including Reassign) can use them.
                int currentStep = req.GetAttributeValue<int?>(FieldCurrentStep) ?? 1;
                string json = req.GetAttributeValue<string>(FieldChainJson);

                Guid caller = context.InitiatingUserId;

                // Org base url for the deep link, resolved once (empty if the env var is unset).
                string orgBaseUrl = GetEnvVar(service, tracing, EnvVarOrgUrl);
                string actionUrl = GetEnvVar(service, tracing, EnvVarActionUrl);
                string originator = GetEnvVar(service, tracing, EnvVarOriginator);
                string linkUrl = GetEnvVar(service, tracing, EnvVarDecisionLink);
                string appId = ResolveAppId(service, tracing);

                // ---- Complete Project Setup: admin-only, stamps the Project Number and closes ----
                if (isCompleteSetup)
                {
                    if (!IsInAdminTeam(service, caller, tracing))
                        throw new InvalidPluginExecutionException("Only PAMS administrators can complete project setup.");
                    if (statusVal != StatusPendingProjectSetup)
                        throw new InvalidPluginExecutionException("Project setup can only be completed while the request is Pending Project Setup.");
                    string projNum = (In<string>(context, "ProjectNumber") ?? "").Trim();
                    if (string.IsNullOrWhiteSpace(projNum))
                        throw new InvalidPluginExecutionException("A Project Number is required to complete project setup.");

                    var csUpd = new Entity(EntityRequest, requestId);
                    csUpd[FieldProjectNumber] = projNum;
                    csUpd[FieldStatus] = new OptionSetValue(StatusProjectSetupComplete);
                    csUpd[FieldAssignedTo] = null;   // lifecycle finished; nobody is actioning it
                    csUpd[FieldCurrentRule] = null;  // lifecycle finished; no current approval step
                    // Mark the terminal Project Setup step done in the chain so the stepper shows it
                    // completed (green) with a decision date. Deserialize locally from `json` (the
                    // shared `chain` variable isn't declared until after this early branch). No-op for
                    // legacy chains without a setup step.
                    if (!string.IsNullOrWhiteSpace(json))
                    {
                        try
                        {
                            var csChain = Deserialize(json);
                            var csSetupStep = csChain.FirstOrDefault(s => s.IsSetup);
                            if (csSetupStep != null)
                            {
                                csSetupStep.StatusLabel = "Approved";
                                csSetupStep.DecisionDate = DateTime.UtcNow.ToString("o");
                                csSetupStep.DecisionComment = "Project Number: " + projNum;
                                csUpd[FieldChainJson] = Serialize(csChain);
                            }
                        }
                        catch (Exception ex) { tracing.Trace("CompleteSetup chain update skipped (non-fatal): {0}", ex.Message); }
                    }
                    service.Update(csUpd);

                    // `actor` isn't in scope yet at this point in the method, so resolve the
                    // caller's name locally (same approach the Reassign branch below uses).
                    string csActor = UserName(service, caller);
                    PostNote(factory, tracing, caller, requestId, "Project Setup Complete",
                        csActor + " completed project setup. Project Number: " + projNum + ".");

                    // DEF-006: close the loop with the PM - the lifecycle previously ended silently.
                    var csPm = req.GetAttributeValue<EntityReference>(FieldProjectManager)
                               ?? req.GetAttributeValue<EntityReference>(FieldCreatedBy);
                    if (csPm != null)
                        LogSetupCompleteEmail(service, tracing, req, requestId,
                            CardStr(req, FieldTitle), CardStr(req, FieldIdentifier),
                            projNum, csPm.Id, caller, orgBaseUrl, linkUrl);

                    Out(context, StatusProjectSetupComplete, currentStep,
                        "Project setup complete. Project Number: " + projNum + ".");
                    return;
                }

                // ---- Reassign: admin-only, handled before the standard approver-authority path ----
                if (isReassign)
                {
                    if (reassignStep <= 0)
                        throw new InvalidPluginExecutionException("Step must be a positive integer.");
                    if (!Guid.TryParse(newApproverIdStr, out Guid newApproverId))
                        throw new InvalidPluginExecutionException("NewApproverId is not a valid GUID.");
                    if (string.IsNullOrWhiteSpace(json))
                        throw new InvalidPluginExecutionException("This request has no approval chain.");

                    var rChain = Deserialize(json);
                    var rTarget = rChain.FirstOrDefault(s => s.Step == reassignStep);
                    if (rTarget == null)
                        throw new InvalidPluginExecutionException("Step " + reassignStep + " not found in the chain.");

                    // ===== DEVIATION FROM REQUIREMENTS - NOT YET APPROVED =====================
                    // Requirements (PAMS_Requirements_1-30-2026) scope reassignment to admins:
                    //   Sec 33.3   "Admins have the ability to fully edit the approval chain"
                    //   Sec 33.3.2 "Admin can change the approver of a position within the approval chain"
                    //   Sec 57.5   lists "Assigned To (system-generated)" among the fields an approver
                    //              "cannot edit even when it's their turn to approve" - and reassigning
                    //              the current step is a write to Assigned To.
                    // What approvers ARE granted is ADDITION only:
                    //   Sec 31.1   "Approvers in the workflow can add additional Approver to the workflow"
                    //   Sec 31.1.1 "Manually added approvers are inserted AFTER the current approver"
                    //   Sec 31.4   they may delete an approver THEY added, if that person hasn't approved
                    // The block below additionally lets the CURRENT APPROVER reassign their own step.
                    // That is a stakeholder request (Jul 2026) that has NOT been through change control
                    // with Kyle White / Austin Van Black. Either get it ratified into the doc, or delete
                    // the !reassignByAdmin branch below to restore the admin-only rule.
                    // ==========================================================================
                    // WHO may reassign:
                    //  - an administrator: any un-acted step, including the Project Setup step;
                    //  - the CURRENT approver: their OWN step only - i.e. hand off the approval that
                    //    is sitting with them right now. They may not touch a step further down the
                    //    chain, a step already acted on, or the admin-owned setup step.
                    // The authority check has to live here, not just in the form: the action is
                    // callable directly, so the form's button visibility is convenience, not control.
                    bool reassignByAdmin = IsInAdminTeam(service, caller, tracing);
                    if (!reassignByAdmin)
                    {
                        if (rTarget.IsSetup)
                            throw new InvalidPluginExecutionException("Only PAMS administrators can change the setup assignee.");
                        if (rTarget.Step != currentStep)
                            throw new InvalidPluginExecutionException("You can only reassign the step that is currently awaiting your approval.");
                        if (!IsStepApprover(service, rTarget, caller, tracing))
                            throw new InvalidPluginExecutionException("Only the current approver or a PAMS administrator can reassign this step.");
                        tracing.Trace("Reassign of step {0} by current approver {1} (not an admin).", reassignStep, caller);
                    }

                    // Two reassign contexts:
                    //  - Approval steps: allowed only while the request is Pending approval.
                    //  - The Project Setup step: allowed while the request is still Pending approval
                    //    (pre-assign the setup owner before it gets there) OR while Pending Project
                    //    Setup (change who's actively doing setup). The new assignee MUST be a
                    //    PAMS - Administrators member (setup is admin-owned).
                    if (rTarget.IsSetup)
                    {
                        if (statusVal != StatusPendingProjectSetup && statusVal != StatusPending)
                            throw new InvalidPluginExecutionException("The setup assignee can only be changed while the request is pending approval or Pending Project Setup.");
                        if (!IsInAdminTeam(service, newApproverId, tracing))
                            throw new InvalidPluginExecutionException("The setup assignee must be a member of the PAMS - Administrators team.");
                    }
                    else
                    {
                        if (statusVal != StatusPending)
                            throw new InvalidPluginExecutionException("Approvers can only be changed while the request is pending approval.");
                    }

                    string rActed = (rTarget.StatusLabel ?? "").ToLowerInvariant().Trim();
                    if (rActed == "approved" || rActed == "rejected" || rActed.IndexOf("changes") > -1)
                        throw new InvalidPluginExecutionException("That step has already been acted on and cannot be reassigned.");

                    string rNewName = UserName(service, newApproverId);
                    string rOldName = string.IsNullOrEmpty(rTarget.Approver) ? "(unassigned)" : rTarget.Approver;
                    // Keep the OUTGOING approver's id so we can CC them (DEF-004) - capture before overwrite.
                    Guid rOldApproverId = Guid.Empty;
                    Guid.TryParse(rTarget.ApproverId ?? "", out rOldApproverId);
                    rTarget.Approver = rNewName;
                    rTarget.ApproverId = newApproverId.ToString();

                    var rUpd = new Entity(EntityRequest, requestId);
                    rUpd[FieldChainJson] = Serialize(rChain);
                    // Update Assigned To when the CURRENT approval step's approver changed. For the
                    // setup step, only repoint Assigned To when the request is ACTUALLY in Pending
                    // Project Setup (the setup person is the active assignee then). Reassigning the
                    // setup step DURING approval just pre-sets a Future step; the current approver must
                    // keep Assigned To.
                    if (reassignStep == currentStep && !rTarget.IsSetup)
                        rUpd[FieldAssignedTo] = new EntityReference("systemuser", newApproverId);
                    else if (rTarget.IsSetup && statusVal == StatusPendingProjectSetup)
                        rUpd[FieldAssignedTo] = new EntityReference("systemuser", newApproverId);
                    // Build the card for the reassigned current approver so we can email it. The setup
                    // step has no approval card (its action is Complete Setup, not Approve), so skip it.
                    string rCardHtml = null;
                    if (reassignStep == currentStep && !rTarget.IsSetup)
                    {
                        DateTime? rSubmitLocal = ResolveSubmitLocal(service, tracing, req, FieldSubmissionDt, null, FieldCreatedBy);
                        string rCardJson = BuildCard(service, tracing, req, requestId, rChain, currentStep, orgBaseUrl, actionUrl, originator, linkUrl, appId, rSubmitLocal);
                        rCardHtml = BuildCardHtml(service, tracing, rCardJson, req, requestId, rChain, currentStep, orgBaseUrl, linkUrl, appId, rSubmitLocal);
                    }
                    service.Update(rUpd);

                    // A new card is emailed to the new approver when the CURRENT approval step changed,
                    // CC'ing the outgoing approver (DEF-004). The setup step notifies differently below.
                    if (reassignStep == currentStep && !rTarget.IsSetup)
                        LogApprovalEmail(service, tracing, req, requestId,
                            CardStr(req, FieldTitle), CardStr(req, FieldIdentifier), currentStep,
                            rTarget.Role, newApproverId, rCardHtml, rOldApproverId);

                    // Not for the Project Setup step: that assignee is an admin performing the
                    // post-approval setup task (reqs 87, 88), not an approver. Admins already have
                    // access to every request (req 54), so the row would grant nothing while
                    // listing them as a stakeholder - and being system-added it could not then be
                    // removed (req 52). Mirrors the same skip in EnsureChainWatchers.
                    if (!rTarget.IsSetup)
                    {
                        EnsureWatcher(service, tracing, requestId, newApproverId, caller);

                        // Set the ACCESS to match the position they now hold. EnsureWatcher creates
                        // the row, and RequestWatcherSharing grants Read on Create - but Read is
                        // only right for a FUTURE step. If they have just been made the CURRENT
                        // approver they need Write, or they would be asked to decide on a request
                        // they cannot edit (reqs 56, 58).
                        var rShareSvc = systemServiceForShares(factory);
                        // Level comes from the user's position in the WHOLE chain, not from the
                        // step being reassigned.
                        //
                        // This used to test `reassignStep == currentStep`, which is a fact about
                        // the EDIT rather than about the person. Putting someone who is already the
                        // current approver onto a later step evaluated (3 == 1) -> false -> Read,
                        // silently downgrading the Write they hold for the step they are actually
                        // being waited on for. One person can occupy several steps - it is normal
                        // in these chains - so the answer has to be the HIGHEST level any of their
                        // positions justifies.
                        SetWatcherAccess(rShareSvc, tracing, requestId, newApproverId,
                            LevelForChainPosition(rChain, currentStep, newApproverId));
                        foreach (var ob in rTarget.OtherValidApproverIds ?? new List<string>())
                            if (Guid.TryParse((ob ?? "").Replace("{", "").Replace("}", ""), out Guid obId))
                                SetWatcherAccess(rShareSvc, tracing, requestId, obId,
                                    LevelForChainPosition(rChain, currentStep, obId));

                        // The REPLACED approver is out of the chain, so their access goes - unless
                        // they still hold another step (or are a backup on one), which happens when
                        // the same person covers more than one role. Their watcher ROW is kept
                        // either way: req 52 forbids deleting a system-added watcher, and it is a
                        // legitimate record that they were once in the chain.
                        if (rOldApproverId != Guid.Empty && rOldApproverId != newApproverId)
                        {
                            bool stillInChain = rChain.Any(cs =>
                                (Guid.TryParse((cs.ApproverId ?? "").Replace("{", "").Replace("}", ""), out Guid csId)
                                     && csId == rOldApproverId)
                                || (cs.OtherValidApproverIds ?? new List<string>()).Any(o =>
                                     Guid.TryParse((o ?? "").Replace("{", "").Replace("}", ""), out Guid oid)
                                     && oid == rOldApproverId));
                            if (!stillInChain)
                            {
                                // Out of the workflow - but that only settles the APPROVER part of
                                // their access. Someone can be a watcher AND an approver: a person
                                // manually adds them, they later get put on a step, then get taken
                                // off it again. EnsureWatcher leaves the existing row alone, so it
                                // still reads source = Manual - and revoking here would strip the
                                // access a person deliberately gave them, which is not something
                                // the chain gets to decide.
                                // Falls back to Read (the watcher norm, req 48.2) rather than
                                // Revoked in that case. Matches SyncWatcherShares, which already
                                // keeps manual rows through a chain change - the two paths would
                                // otherwise disagree about the same row.
                                int fallback = WatcherRowIsChainDerived(service, tracing, requestId, rOldApproverId)
                                    ? AccessLevelRevoked
                                    : AccessLevelRead;
                                SetWatcherAccess(rShareSvc, tracing, requestId, rOldApproverId, fallback);
                                tracing.Trace("Replaced approver {0} left the chain; access set to {1}.",
                                              rOldApproverId, fallback);
                            }
                            else
                            {
                                // Still in the chain, so they keep visibility - at whatever level
                                // their REMAINING positions justify. Usually Read, but Write if one
                                // of those positions is the current step (they were replaced on a
                                // different step while still being the person waited on).
                                int keepLevel = LevelForChainPosition(rChain, currentStep, rOldApproverId);
                                SetWatcherAccess(rShareSvc, tracing, requestId, rOldApproverId, keepLevel);
                                tracing.Trace("Replaced approver {0} holds another step; access set to {1}.",
                                              rOldApproverId, keepLevel);
                            }
                        }
                    }
                    string rWhat = rTarget.IsSetup ? "setup assignee" : ("approver for step " + reassignStep);
                    // Name the administrator. "An administrator changed ..." forces the reader into
                    // the audit log to answer the obvious follow-up (req 33.3.2.3 requires the
                    // detail be captured). Falls back to the generic wording if the lookup fails.
                    string rActorName = UserName(service, caller);
                    string rWho = string.IsNullOrWhiteSpace(rActorName)
                        ? "An administrator"
                        : (rActorName + " (Administrator)");
                    PostNote(factory, tracing, caller, requestId, rTarget.IsSetup ? "Setup Assignee Changed" : "Approver Changed",
                        rWho + " changed the " + rWhat +
                        " from " + rOldName + " to " + rNewName + ".");

                    context.OutputParameters["ChainJson"] = Serialize(rChain);
                    Out(context, statusVal, currentStep,
                        (rTarget.IsSetup ? "Setup assignee" : ("Approver for step " + reassignStep)) + " changed to " + rNewName + ".");
                    return;
                }

                // Status guard differs by action:
                //  - Approve/Reject/RequestChanges act on an in-flight step -> must be Pending.
                //  - Cancel (req 93.1.1 / 93.2.4) is allowed any time the request is NOT yet Approved.
                if (isCancel)
                {
                    // Once fully approved (or in project-setup), the request can no longer be cancelled.
                    if (statusVal == StatusApproved
                        || statusVal == StatusPendingProjectSetup
                        || statusVal == StatusProjectSetupComplete)
                        throw new InvalidPluginExecutionException("An approved request can no longer be cancelled.");
                }
                else
                {
                    if (statusVal != StatusPending)
                        throw new InvalidPluginExecutionException("This request is not pending approval.");

                    // Stale-link / duplicate-click guard: the email decision links carry the step
                    // they were generated for. If that step no longer matches the request's current
                    // step, the request has already moved on (someone acted, or this link was used
                    // already) - reject so a re-clicked or outdated link can't act on a later step.
                    // (reassignStep holds the "Step" input; 0/absent means "not provided" - e.g. an
                    // in-app decision that doesn't pass Step - so we only enforce when it's > 0.)
                    if (reassignStep > 0 && reassignStep != currentStep)
                        throw new InvalidPluginExecutionException(
                            "This request has already moved past the step this link was for. "
                            + "It is now at step " + currentStep + ". No action was taken.");
                }

                // Cancel doesn't require an in-flight chain/step; the approve-family does.
                List<ChainStep> chain = null;
                ChainStep step = null;
                if (!isCancel)
                {
                    if (string.IsNullOrWhiteSpace(json))
                        throw new InvalidPluginExecutionException("This request has no approval chain.");
                    chain = Deserialize(json);
                    step = chain.FirstOrDefault(s => s.Step == currentStep);
                    if (step == null)
                        throw new InvalidPluginExecutionException("Current step not found in the chain.");
                }

                // ---- Authority check ----
                bool isAdmin = IsInAdminTeam(service, caller, tracing);
                // The actor recorded on the decision. Normally the caller; for email-delivered
                // decisions it's the step's designated approver (the flow account isn't the actor).
                Guid actorId = caller;
                bool authorized;
                if (isCancel)
                {
                    // PM (creator) cancelling their own request (93.1.1), or an admin (93.2).
                    var creator = req.GetAttributeValue<EntityReference>(FieldCreatedBy);
                    bool isOwner = creator != null && creator.Id == caller;
                    authorized = isOwner || isAdmin;
                    // Admin cancelling on behalf of another user requires a comment (93.2.2).
                    if (isAdmin && !isOwner && string.IsNullOrWhiteSpace(comment))
                        throw new InvalidPluginExecutionException("A comment is required to cancel on behalf of another user.");
                }
                else if (onBehalf)
                {
                    // Admin explicitly acting on behalf of an approver (req 33.1). BUT if the caller
                    // is actually the current step's approver, they act as THEMSELVES - being an admin
                    // doesn't turn your own approval into an on-behalf one. Only a non-approver admin
                    // is truly acting on behalf.
                    if (IsStepApprover(service, step, caller, tracing))
                    {
                        onBehalf = false;    // it's their own decision, not on-behalf
                        authorized = true;
                    }
                    else
                    {
                        // Requires admin rights and a comment (comment checked earlier).
                        authorized = isAdmin;
                    }
                }
                else
                {
                    // DEF-029: every caller now reaches this API as the REAL signed-in user (the form
                    // and the authenticated action page both run as the logged-in user; the old
                    // unauthenticated email/flow path is gone). So authorization is strict:
                    //   - the current step's approver (or an Other Valid Approver) acts as themselves;
                    //   - an admin may act on behalf of the approver (attributed to the approver,
                    //     flagged on-behalf, comment required - same rule as explicit OnBehalf);
                    //   - anyone else is refused.
                    if (IsStepApprover(service, step, caller, tracing))
                    {
                        authorized = true;   // acting as themselves
                    }
                    else if (isAdmin && step != null)
                    {
                        // Admin acting on an approver's step without the explicit OnBehalf flag.
                        // Treat as on-behalf: require a comment and attribute to the step approver.
                        if (string.IsNullOrWhiteSpace(comment))
                            throw new InvalidPluginExecutionException(
                                "A comment is required when an administrator acts on behalf of the assigned approver.");
                        authorized = true;
                        onBehalf = true;   // drives the on-behalf attribution/note below
                        if (!string.IsNullOrEmpty(step.ApproverId)
                            && Guid.TryParse(step.ApproverId, out Guid stepApprover))
                            actorId = stepApprover;
                        tracing.Trace("Admin {0} acting on behalf of step {1} approver {2}.",
                            caller, currentStep, actorId);
                    }
                    else
                    {
                        // Not the approver, not an admin - refuse (this is the DEF-029 guarantee).
                        authorized = false;
                    }
                }
                if (!authorized)
                {
                    string approverName = (step != null && !string.IsNullOrEmpty(step.Approver))
                        ? step.Approver : "the assigned approver";
                    throw new InvalidPluginExecutionException(
                        "You are not authorized to act on this request. It is awaiting approval from "
                        + approverName + ". Only that approver or a PAMS administrator can act on it.");
                }

                string actorNote = onBehalf ? " (on behalf, by admin)" : "";
                DateTime now = DateTime.UtcNow;
                string actor = UserName(service, actorId);   // for the timeline story (the approver, not the flow account on the email path)
                string role = step != null ? step.Role : "";

                // ON-BEHALF ATTRIBUTION.
                // actorId is deliberately switched to the STEP APPROVER above so the decision is
                // recorded against the approval position. The side effect was that the person who
                // actually clicked vanished: the timeline and the chain both read "Stephen Curry
                // approved", when Tony Dawson did it on his behalf. Req 33.1.1 requires the audit
                // capture this, and 33.1.3 asks for the approver's name in parentheses.
                // So: lead with the REAL actor, and name the capacity and the approver they acted
                // for. Not on-behalf -> unchanged, just the person and their role.
                string onBehalfLabel = null;
                if (onBehalf)
                {
                    string adminName = UserName(service, caller);
                    string forName = (step != null && !string.IsNullOrWhiteSpace(step.Approver))
                        ? step.Approver
                        : (string.IsNullOrWhiteSpace(actor) ? "the assigned approver" : actor);
                    string capacity = string.IsNullOrWhiteSpace(role)
                        ? ("Admin on behalf of " + forName)
                        : ("Admin on behalf of " + role + ", " + forName);
                    onBehalfLabel = string.IsNullOrWhiteSpace(adminName)
                        ? ("(" + capacity + ")")
                        : (adminName + " (" + capacity + ")");
                }
                // Attach the role to the NAME rather than trailing it after the step number:
                // "Trent Roehler (VP) approved step 1" reads as a person acting in a capacity;
                // "Trent Roehler approved step 1 (VP)" reads as a property of the step.
                // Must be declared after `role`. Degrades cleanly when either part is unknown.
                // "Tony Dawson (Admin on behalf of Controlling Manager, Stephen Curry)" when acting
                // on behalf; otherwise "Stephen Curry (Controlling Manager)".
                string actorLabel = onBehalfLabel ?? NameWithRole(actor, role);

                if (isApprove)
                {
                    step.StatusLabel = "Approved";
                    step.DecisionComment = comment;
                    step.DecisionDate = now.ToString("o");
                    step.DecidedBy = onBehalfLabel;   // null unless an admin acted on behalf

                    var maxStep = chain.Max(s => s.Step);
                    var setupStep = chain.FirstOrDefault(s => s.IsSetup);
                    // The last APPROVAL step is the highest-numbered non-setup step. When it's approved,
                    // we advance INTO the setup step (which is now a real, terminal chain step) rather
                    // than ending the chain. Legacy chains built before this change have no setup step,
                    // so fall back to the old "last step = done" behavior in that case.
                    int lastApprovalStep = setupStep != null
                        ? chain.Where(s => !s.IsSetup).Select(s => s.Step).DefaultIfEmpty(0).Max()
                        : maxStep;
                    var upd = new Entity(EntityRequest, requestId);
                    if (currentStep >= lastApprovalStep)
                    {
                        // Final approval step done -> advance to Project Setup (req 86). Status becomes
                        // Approved - Pending Project Setup; the setup step becomes the current step so
                        // the stepper shows it active. An Admin then enters the Project Number and
                        // clicks Complete Project Setup (the CompleteSetup decision) to finish.
                        upd[FieldStatus] = new OptionSetValue(StatusPendingProjectSetup);

                        EntityReference setupOwner = null;
                        if (setupStep != null)
                        {
                            // Make the setup step the current step and mark it active.
                            setupStep.StatusLabel = "Current Approver";
                            upd[FieldCurrentStep] = setupStep.Step;
                            upd[FieldCurrentRule] = null;   // setup step isn't governed by an approval rule
                            // Assign to the setup step's SNAPSHOTTED approver (the primary at build time).
                            // If that snapshot was blank (no primary flagged then), resolve the current
                            // primary now; failing that, fall back to the PM/creator.
                            if (!string.IsNullOrEmpty(setupStep.ApproverId)
                                && Guid.TryParse(setupStep.ApproverId.Replace("{", "").Replace("}", ""), out Guid setupApp))
                                setupOwner = new EntityReference("systemuser", setupApp) { Name = setupStep.Approver };
                            else
                            {
                                setupOwner = FindPrimaryAdministrator(service, tracing)
                                             ?? req.GetAttributeValue<EntityReference>(FieldCreatedBy);
                                // Backfill the step so the stepper shows a name and reassign has a base.
                                if (setupOwner != null)
                                {
                                    setupStep.ApproverId = setupOwner.Id.ToString();
                                    setupStep.Approver = setupOwner.Name ?? "";
                                }
                            }
                        }
                        else
                        {
                            // Legacy chain (no setup step): preserve original behavior.
                            setupOwner = FindPrimaryAdministrator(service, tracing)
                                         ?? req.GetAttributeValue<EntityReference>(FieldCreatedBy);
                        }

                        upd[FieldChainJson] = Serialize(chain);
                        if (setupOwner != null) upd[FieldAssignedTo] = setupOwner;
                        service.Update(upd);

                        // Step the FINAL approver down from Write to Read.
                        //
                        // This branch runs when the last APPROVAL step is approved and the request
                        // moves to Pending Project Setup. The access hand-over lived only in the
                        // "advance to the next step" branch below, so the final approver kept Write
                        // indefinitely - they had approved, but the record was still editable by
                        // them, which reqs 58 and 60 forbid just as much as for any other step.
                        //
                        // LevelForChainPosition is given the SETUP step as the current one (or 0
                        // when there is no setup step), so nobody matches "current approver" and
                        // everyone in the chain settles at Read. That is deliberate: having
                        // approved is not the same as being removed from the workflow, so they keep
                        // visibility of what they approved rather than being Revoked.
                        {
                            var sysShareFinal = systemServiceForShares(factory);
                            int setupStepNo = setupStep != null ? setupStep.Step : 0;
                            var doneFor = new HashSet<Guid>();
                            foreach (var cs in chain)
                            {
                                if (cs == null || cs.IsSetup) continue;
                                foreach (var idText in ChainStepPrincipals(cs))
                                {
                                    Guid pid;
                                    if (!Guid.TryParse(idText.Replace("{", "").Replace("}", ""), out pid)) continue;
                                    if (!doneFor.Add(pid)) continue;
                                    SetWatcherAccess(sysShareFinal, tracing, requestId, pid,
                                        LevelForChainPosition(chain, setupStepNo, pid));
                                }
                            }
                            // The person who actually clicked, when acting on behalf.
                            if (doneFor.Add(actorId))
                                SetWatcherAccess(sysShareFinal, tracing, requestId, actorId,
                                    LevelForChainPosition(chain, setupStepNo, actorId));
                        }

                        PostNote(factory, tracing, caller, requestId, "Fully Approved",
                            actorLabel + " approved the final step. The request is now Approved - Pending Project Setup." +
                            (string.IsNullOrWhiteSpace(comment) ? "" : " Comment: " + comment));
                        // Notify the PAMS - Administrators team that setup is needed.
                        LogAdminSetupEmail(service, tracing, req, requestId,
                            CardStr(req, FieldTitle), CardStr(req, FieldIdentifier), caller, orgBaseUrl, linkUrl);
                        Out(context, StatusPendingProjectSetup, currentStep, "Request fully approved; pending project setup." + actorNote);
                    }
                    else
                    {
                        // Advance to next step; mark it current in the chain snapshot.
                        int next = currentStep + 1;
                        var nextStep = chain.FirstOrDefault(s => s.Step == next);
                        if (nextStep != null) nextStep.StatusLabel = "Current Approver";
                        upd[FieldCurrentStep] = next;
                        upd[FieldChainJson] = Serialize(chain);
                        upd[FieldCurrentRule] = RuleRefFromStep(nextStep);  // point lookup at new step's rule

                        // Assigned To -> the new current approver so the field/views/grid stay accurate.
                        if (nextStep != null && !string.IsNullOrEmpty(nextStep.ApproverId)
                            && Guid.TryParse(nextStep.ApproverId.Replace("{", "").Replace("}", ""), out Guid nextAssignee))
                            upd[FieldAssignedTo] = new EntityReference("systemuser", nextAssignee);

                        // Hand WRITE from the outgoing approver to the incoming one (reqs 58, 60).
                        // Done here rather than in the chain builder because an ADVANCE doesn't
                        // rebuild the chain.
                        //
                        // Every level is computed from the user's position in the chain AS IT NOW
                        // STANDS, with `next` as the current step - not hardcoded per role. One
                        // person can hold several steps: someone who just approved step 1 and also
                        // holds step 3 must drop to Read until step 3 comes round, while someone
                        // who holds steps 1 AND 2 must KEEP Write, because the decision is still
                        // theirs. Hardcoding "outgoing = Read, incoming = Write" got the second
                        // case right only because the incoming assignment happened to run last;
                        // reverse the order and it would silently strip the current approver.
                        var sysShare = systemServiceForShares(factory);

                        var touched = new HashSet<Guid>();
                        Action<string> applyFor = idText =>
                        {
                            Guid pid;
                            if (string.IsNullOrWhiteSpace(idText)) return;
                            if (!Guid.TryParse(idText.Replace("{", "").Replace("}", ""), out pid)) return;
                            if (!touched.Add(pid)) return;   // one decision per person
                            SetWatcherAccess(sysShare, tracing, requestId, pid,
                                LevelForChainPosition(chain, next, pid));
                        };

                        if (step != null)
                        {
                            applyFor(step.ApproverId);
                            foreach (var ob in step.OtherValidApproverIds ?? new List<string>()) applyFor(ob);
                        }
                        if (nextStep != null)
                        {
                            applyFor(nextStep.ApproverId);
                            foreach (var ob in nextStep.OtherValidApproverIds ?? new List<string>()) applyFor(ob);
                        }
                        // The person who actually clicked, when acting on behalf of the approver.
                        applyFor(actorId.ToString());

                        // Build the resolved approval card for the NEW current approver.
                        // (No longer stored on pams_adaptivecardjson - carried in email description.)
                        DateTime? advSubmitLocal = ResolveSubmitLocal(service, tracing, req, FieldSubmissionDt, null, FieldCreatedBy);
                        string advCardJson = BuildCard(service, tracing, req, requestId, chain, next, orgBaseUrl, actionUrl, originator, linkUrl, appId, advSubmitLocal);
                        string advCardHtml = BuildCardHtml(service, tracing, advCardJson, req, requestId, chain, next, orgBaseUrl, linkUrl, appId, advSubmitLocal);

                        service.Update(upd); // ApproverSharingPlugin shares/notifies the new current approver
                        string nextRole = nextStep != null ? nextStep.Role : "";
                        // Log the notification email to the new current approver (non-fatal).
                        Guid? nextApproverId = null;
                        if (nextStep != null && !string.IsNullOrEmpty(nextStep.ApproverId)
                            && Guid.TryParse(nextStep.ApproverId, out Guid nApp)) nextApproverId = nApp;
                        LogApprovalEmail(service, tracing, req, requestId,
                            CardStr(req, FieldTitle), CardStr(req, FieldIdentifier), next, nextRole, nextApproverId, advCardHtml);
                        PostNote(factory, tracing, caller, requestId, "Step Approved",
                            actorLabel + " approved step " + currentStep + ". Advanced to " +
                            (string.IsNullOrEmpty(nextRole) ? "the next approver" : nextRole) + "." +
                            (string.IsNullOrWhiteSpace(comment) ? "" : " Comment: " + comment));
                        Out(context, StatusPending, next, "Approved. Advanced to step " + next + "." + actorNote);
                    }
                }
                else if (isReject)
                {
                    // Rejected (req 91): status Rejected, Assigned To blank, editable.
                    step.StatusLabel = "Rejected";
                    step.DecidedBy = onBehalfLabel;   // null unless an admin acted on behalf
                    step.DecisionComment = comment;
                    step.DecisionDate = now.ToString("o");

                    var upd = new Entity(EntityRequest, requestId);
                    upd[FieldStatus] = new OptionSetValue(StatusRejected);
                    upd[FieldAssignedTo] = null;              // Assigned To now blank (req 91)
                    upd[FieldChainJson] = Serialize(chain);
                    upd[FieldCurrentRule] = null;             // no active approval step while returned
                    // Snapshot the request details as of this return, so a later resubmit can detect
                    // (and require) real changes and log exactly what changed.
                    try { upd[FieldReturnSnapshot] = PamsSnapshot.Serialize(PamsSnapshot.Capture(service, EntityRequest, requestId)); }
                    catch (Exception se) { tracing.Trace("Return snapshot (reject) failed (non-fatal): {0}", se.Message); }
                    service.Update(upd);
                    PostNote(factory, tracing, caller, requestId, "Rejected",
                        actorLabel + " rejected the request at step " + currentStep + ". Comment: " + comment);
                    // Notify the PM (creator) that the request was rejected, with the reason.
                    LogReturnEmail(service, tracing, req, requestId,
                        CardStr(req, FieldTitle), CardStr(req, FieldIdentifier), role, comment, caller, orgBaseUrl, linkUrl, true);
                    Out(context, StatusRejected, currentStep, "Request rejected." + actorNote);
                }
                else if (isChanges)
                {
                    // Changes Requested (req 90): status Changes Requested, Assigned To -> PM, editable.
                    step.StatusLabel = "Changes Requested";
                    step.DecidedBy = onBehalfLabel;   // null unless an admin acted on behalf
                    step.DecisionComment = comment;
                    step.DecisionDate = now.ToString("o");

                    // pams_assignedtoid is a lookup -> systemuser. Prefer the current Project
                    // Manager (defaults to the creator but can be reassigned); fall back to creator.
                    var pmRef = req.GetAttributeValue<EntityReference>(FieldProjectManager)
                                ?? req.GetAttributeValue<EntityReference>(FieldCreatedBy);
                    var upd = new Entity(EntityRequest, requestId);
                    upd[FieldStatus] = new OptionSetValue(StatusChanges);
                    if (pmRef != null) upd[FieldAssignedTo] = pmRef;   // back to Project Manager (req 90)
                    upd[FieldChainJson] = Serialize(chain);
                    upd[FieldCurrentRule] = null;             // no active approval step while returned
                    // Snapshot the request details as of this return (see reject block).
                    try { upd[FieldReturnSnapshot] = PamsSnapshot.Serialize(PamsSnapshot.Capture(service, EntityRequest, requestId)); }
                    catch (Exception se) { tracing.Trace("Return snapshot (changes) failed (non-fatal): {0}", se.Message); }
                    service.Update(upd);
                    // Name the PM rather than saying "the project manager" - the reader of this note
                    // is often trying to work out who the ball is with.
                    string pmLabelCR = (pmRef != null && !string.IsNullOrWhiteSpace(pmRef.Name))
                        ? (pmRef.Name + " (Project Manager)") : "the project manager";
                    PostNote(factory, tracing, caller, requestId, "Changes Requested",
                        actorLabel + " requested changes at step " + currentStep + ". Returned to "
                        + pmLabelCR + " for edits. Comment: " + comment);
                    // Notify the PM (creator) that changes are needed, with the approver's comment.
                    LogReturnEmail(service, tracing, req, requestId,
                        CardStr(req, FieldTitle), CardStr(req, FieldIdentifier), role, comment, caller, orgBaseUrl, linkUrl, false);
                    Out(context, StatusChanges, currentStep, "Changes requested." + actorNote);
                }
                else // Cancel (req 93)
                {
                    // Cancel: move the request to Cancelled. Reopens for editing; a resubmit
                    // restarts the workflow at step 1. Reset the workflow pointer and clear the
                    // chain now so the request doesn't carry the prior cycle's approvals/dates into
                    // the resubmit. (Previously the stale chain lingered, and the builder's resubmit
                    // detection - which keys on returned-step labels - didn't fire for Cancelled,
                    // leaving an old "Approved" step visible after resubmit.)
                    var upd = new Entity(EntityRequest, requestId);
                    upd[FieldStatus] = new OptionSetValue(StatusCancelled);
                    upd[FieldAssignedTo] = null;   // no longer assigned to an approver
                    upd[FieldCurrentStep] = 1;     // reset pointer so resubmit starts at step 1
                    upd[FieldChainJson] = null;    // drop the prior chain; builder rebuilds on resubmit
                    upd[FieldCurrentRule] = null;  // no active approval step
                    service.Update(upd);

                    // Withdraw access to a request that is no longer live. Cancelled is a terminal
                    // state in this build (it has its OWN status value; req 93's "moves to Changes
                    // Requested or Rejected" describes a different design), so a user may never
                    // resubmit - leaving every approver and watcher able to open it indefinitely.
                    //
                    // The WATCHER ROWS are deliberately left alone: they are the record of who may
                    // view (reqs 48, 51), req 52 forbids deleting the auto-added ones, and the
                    // re-grant on resubmit reads from them. Rows are the source of truth; the
                    // shares are derived state, rebuilt from the rows when the chain is rebuilt.
                    // Sets pams_accesslevel = None on every watcher row (except the PM's) AND
                    // revokes. The field is the INTENT; the revoke makes reality match it now.
                    // Recording it on the row is what makes the state queryable and what lets a
                    // later resubmit see that access was deliberately withdrawn rather than
                    // never granted.
                    RevokeAllWatcherShares(systemServiceForShares(factory), tracing, requestId,
                                           req.GetAttributeValue<EntityReference>(FieldProjectManager)
                                           ?? req.GetAttributeValue<EntityReference>(FieldCreatedBy));

                    var creatorRef = req.GetAttributeValue<EntityReference>(FieldCreatedBy);
                    bool byAdmin = onBehalf || (IsInAdminTeam(service, caller, tracing)
                                                && !(creatorRef != null && creatorRef.Id == caller));
                    string byWhom = byAdmin ? " (cancelled by admin)" : "";
                    PostNote(factory, tracing, caller, requestId, "Cancelled",
                        actor + " cancelled the request" + (byAdmin ? " (as an administrator)" : "") + "." +
                        (string.IsNullOrWhiteSpace(comment) ? "" : " Reason: " + comment));
                    // DEF-005: tell the PM/requester their request was cancelled - otherwise it just
                    // disappears from their active work with no notice. Prefer the current Project
                    // Manager (it defaults to the creator but can be reassigned); fall back to the
                    // creator.
                    // When the PM cancels their OWN request there's nobody else to tell, so we only
                    // send if they explicitly asked for a copy (NotifySelf) - otherwise we'd be
                    // emailing someone about an action they just took.
                    var cancelPm = req.GetAttributeValue<EntityReference>(FieldProjectManager) ?? creatorRef;
                    bool cancellingOwn = cancelPm != null && cancelPm.Id == caller;
                    // The cancel modal's "Send me an email confirmation" checkbox posts this as
                    // "EmailSelf"; the plugin originally read "NotifySelf". The names never matched,
                    // so In<bool> fell through to default(false) on every cancel and a PM cancelling
                    // their own request never got the copy they asked for. Accept either spelling so
                    // a rename on one side can't silently disable the flag again.
                    bool notifySelf = In<bool>(context, "EmailSelf") || In<bool>(context, "NotifySelf");
                    if (cancelPm != null && (!cancellingOwn || notifySelf))
                        LogCancelEmail(service, tracing, req, requestId,
                            CardStr(req, FieldTitle), CardStr(req, FieldIdentifier),
                            actor, comment, cancelPm.Id, caller, orgBaseUrl, linkUrl);
                    Out(context, StatusCancelled, currentStep, "Request cancelled." + byWhom);
                }
            }
            catch (InvalidPluginExecutionException) { throw; }
            catch (FaultException<OrganizationServiceFault> fault)
            {
                tracing.Trace("Decision fault: {0}", fault.ToString());
                throw new InvalidPluginExecutionException("Approval decision failed: " + fault.Message, fault);
            }
            catch (Exception ex)
            {
                tracing.Trace("Unhandled: {0}", ex.ToString());
                throw new InvalidPluginExecutionException("Approval decision failed: " + ex.Message, ex);
            }
        }

        // Caller is the step's primary approver or one of its Other Valid Approvers (77.8.3).
        private bool IsStepApprover(IOrganizationService service, ChainStep step, Guid caller, ITracingService tracing)
        {
            if (!string.IsNullOrEmpty(step.ApproverId) &&
                Guid.TryParse(step.ApproverId, out Guid primary) && primary == caller)
                return true;

            if (step.OtherValidApproverIds != null)
            {
                foreach (var id in step.OtherValidApproverIds)
                    if (Guid.TryParse(id, out Guid ova) && ova == caller) return true;
            }
            return false;
        }

        private bool IsInAdminTeam(IOrganizationService service, Guid userId, ITracingService tracing)
        {
            var q = new QueryExpression("team")
            {
                ColumnSet = new ColumnSet("teamid"),
                Criteria = new FilterExpression()
            };
            q.Criteria.AddCondition("name", ConditionOperator.Equal, AdminTeamName);
            var link = q.AddLink("teammembership", "teamid", "teamid");
            link.LinkCriteria.AddCondition("systemuserid", ConditionOperator.Equal, userId);
            return service.RetrieveMultiple(q).Entities.Count > 0;
        }

        // Wraps the Adaptive Card JSON in the same HTML shell the comment emails use: an
        // actionable-message script block (rendered by Outlook) plus a plain-text/link fallback.
        // Stored in email.description so one flow can send all PAMS notifications uniformly.
        // Returns the Morton logo for cards. Prefers the embedded base64 data-URI (works in the
        // adaptive-card renderer); falls back to the authenticated web-resource URL if none is set.
        // Logical name of the Morton logo web resource in the solution.
        private const string LogoWebResourceName = "pams_mortonLogo";

        // Build the logo data-URI by reading the web resource at runtime.
        // webresource.content is ALREADY base64 in Dataverse, so it drops straight into a data URI -
        // no hardcoded blob, nothing to re-paste per deployment, and updating the image in the
        // solution updates every email automatically.
        private static string LogoDataUriFromWebResource(IOrganizationService svc, ITracingService tracing)
        {
            if (svc == null) return "";
            try
            {
                var q = new QueryExpression("webresource")
                {
                    ColumnSet = new ColumnSet("content", "webresourcetype"),
                    TopCount = 1,
                    Criteria = new FilterExpression()
                };
                q.Criteria.AddCondition("name", ConditionOperator.Equal, LogoWebResourceName);
                var res = svc.RetrieveMultiple(q);
                if (res == null || res.Entities.Count == 0)
                {
                    if (tracing != null) tracing.Trace("Logo web resource '{0}' not found.", LogoWebResourceName);
                    return "";
                }
                var wr = res.Entities[0];
                string content = wr.GetAttributeValue<string>("content");
                if (string.IsNullOrEmpty(content)) return "";
                string mime = "image/png";
                var wrType = wr.GetAttributeValue<OptionSetValue>("webresourcetype");
                if (wrType != null)
                {
                    switch (wrType.Value)
                    {
                        case 5: mime = "image/png"; break;
                        case 6: mime = "image/jpeg"; break;
                        case 7: mime = "image/gif"; break;
                        case 10: mime = "image/x-icon"; break;
                        case 11: mime = "image/svg+xml"; break;
                    }
                }
                return "data:" + mime + ";base64," + content;
            }
            catch (Exception ex)
            {
                if (tracing != null) tracing.Trace("Could not read logo web resource: {0}", ex.Message);
                return "";
            }
        }

        // Precedence: hardcoded override (normally empty) -> web resource -> authenticated URL.
        // The authenticated URL is a last resort: most mail clients will NOT fetch it, so the logo
        // silently disappears for the recipient. Prefer the data URI.
        private static string ResolveLogo(IOrganizationService svc, ITracingService tracing, string deepLinkOrBaseUrl)
        {
            if (!string.IsNullOrEmpty(LogoDataUri)) return LogoDataUri;
            string fromWr = LogoDataUriFromWebResource(svc, tracing);
            if (!string.IsNullOrEmpty(fromWr)) return fromWr;
            if (string.IsNullOrEmpty(deepLinkOrBaseUrl)) return "";
            int i = deepLinkOrBaseUrl.IndexOf("/main.aspx", StringComparison.OrdinalIgnoreCase);
            string baseUrl = i > 0 ? deepLinkOrBaseUrl.Substring(0, i) : deepLinkOrBaseUrl;
            return baseUrl + "/WebResources/" + LogoWebResourceName;
        }

        private static string LogoFromDeepLink(IOrganizationService svc, ITracingService tracing, string deepLink)
        {
            return ResolveLogo(svc, tracing, deepLink);
        }

        // Branded HTML approval email (Morton logo, layout, progress list, blue buttons) matching the
        // chain-builder's BuildCardHtml, so the advance-to-next-approver email looks identical to the
        // initial notification. The adaptive card JSON is embedded as an Outlook-desktop fallback.
        private static string BuildCardHtml(IOrganizationService service, ITracingService tracing, string cardJson, Entity req, Guid requestId,
            List<ChainStep> steps, int currentStep, string orgBaseUrl, string linkUrl, string appId, DateTime? submitLocal)
        {
            string title = CardStr(req, FieldTitle);
            string identifier = CardStr(req, FieldIdentifier);
            string submittedBy = CardFormatted(req, FieldCreatedBy);
            // Resolved once in Execute, in the SUBMITTER's timezone (see ResolveSubmitLocal).
            string submitDate = CardDate(submitLocal);
            string projectType = CardFormatted(req, FieldProjectType);
            string location = CardFormatted(req, FieldLocation);
            decimal usd = req.GetAttributeValue<decimal?>(FieldUsdAmount)
                          ?? req.GetAttributeValue<decimal?>(FieldBaseAmount) ?? 0m;
            string totalDisp = CardUsd(usd);

            int total = steps.Count;
            string curRole = "", curApproverId = "";
            foreach (var c in steps)
                if (c.Step == currentStep) { curRole = c.Role ?? ""; curApproverId = c.ApproverId ?? ""; break; }

            string logo = ResolveLogo(service, tracing, orgBaseUrl);
            string deepLink = string.IsNullOrEmpty(orgBaseUrl) ? (linkUrl ?? "")
                : (orgBaseUrl.TrimEnd('/') + "/main.aspx?"
                   + (string.IsNullOrEmpty(appId) ? "" : "appid=" + Uri.EscapeDataString(appId) + "&")
                   + "pagetype=entityrecord&etn=" + EntityRequest + "&id=" + requestId);
            Func<string, string> esc = s => System.Security.SecurityElement.Escape(s ?? "");

            var sb = new StringBuilder(6144);
            sb.Append("<html><head>");
            sb.Append("<script type=\"application/adaptivecard+json\">").Append(cardJson).Append("</script>");
            sb.Append("</head>");
            sb.Append("<body style=\"font-family:Segoe UI,Segoe,Arial,sans-serif;margin:0;padding:0;color:#201f1e;\">");
            sb.Append("<div style=\"font-family:Segoe UI,Segoe,Arial,sans-serif;background:#f3f2f1;padding:32px 16px;color:#201f1e;\">");
            // DEF-051: legacy Outlook renders HTML through WORD, which ignores max-width, margin:0 auto,
            // border-radius and box-shadow. The card therefore stretched to the full window width on
            // a wide monitor. A table with a real width attribute is the one layout primitive Word
            // honours, so the 600px column holds everywhere. border-radius / box-shadow are left on
            // the inner div: modern clients round the corners, Word just draws them square, which is
            // cosmetic degradation rather than a broken layout.
            sb.Append("<table role=\"presentation\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\"><tr><td align=\"center\">");
            sb.Append("<table role=\"presentation\" width=\"600\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"width:600px;max-width:600px;\"><tr><td>");
            sb.Append("<div style=\"background:#fff;border:1px solid #e1dfdd;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,.06);overflow:hidden;\">");
            if (!string.IsNullOrEmpty(logo))
                sb.Append("<div style=\"text-align:center;padding:26px 24px 8px;\"><img src=\"").Append(logo)
                  .Append("\" alt=\"Morton Salt\" width=\"190\" style=\"width:190px;max-width:190px;height:auto;border:0;display:inline-block;\" /></div>");
            sb.Append("<div style=\"padding:8px 32px 32px;\">");
            sb.Append("<div style=\"font-size:13px;letter-spacing:.04em;text-transform:uppercase;color:#8a8886;font-weight:600;\">PAMS Project Approval Request</div>");
            sb.Append("<h1 style=\"font-size:26px;margin:2px 0 14px;font-weight:700;\">").Append(esc(title)).Append("</h1>");
            sb.Append("<div style=\"color:#0f6cbd;font-weight:600;font-size:15px;margin-bottom:2px;\">Awaiting your approval</div>");
            sb.Append("<div style=\"color:#605e5c;font-size:13px;margin-bottom:16px;\">").Append(esc(curRole)).Append(" - Step ").Append(currentStep).Append(" of ").Append(total).Append("</div>");
            sb.Append("<div style=\"color:#605e5c;font-size:13px;margin-bottom:18px;\">Submitted by ").Append(esc(submittedBy)).Append(" on ").Append(esc(submitDate)).Append("</div>");

            sb.Append("<table style=\"border-collapse:collapse;font-size:14px;margin-bottom:20px;\">");
            sb.Append(HtmlFactRow("Project ID:", identifier));
            sb.Append(HtmlFactRow("Location:", location));
            sb.Append(HtmlFactRow("Project Type:", projectType));
            sb.Append(HtmlFactRow("Total to be Authorized:", totalDisp));
            sb.Append("</table>");

            sb.Append("<div style=\"font-weight:700;font-size:15px;border-top:1px solid #edebe9;padding-top:14px;margin-bottom:8px;\">Approval Progress</div>");
            sb.Append("<table style=\"border-collapse:collapse;font-size:14px;margin-bottom:18px;\">");
            foreach (var c in steps)
            {
                string who = c.Approver ?? "";
                // When an admin acted on behalf, show WHO ACTUALLY DECIDED rather than the named
                // approver - otherwise the progress list reads as if the approver acted himself.
                if (!string.IsNullOrWhiteSpace(c.DecidedBy)) who = c.DecidedBy;
                if (!string.IsNullOrEmpty(c.StatusLabel)) who += " - " + c.StatusLabel;
                sb.Append("<tr><td style=\"padding:3px 16px 3px 0;color:#8a8886;\">").Append(c.Step).Append(". ").Append(esc(c.Role ?? "")).Append("</td>")
                  .Append("<td style=\"padding:3px 0;\">").Append(esc(who)).Append("</td></tr>");
            }
            sb.Append("</table>");

            // A note the submitter wrote specifically for THIS approver (submit modal). Shown
            // above the attachments line so it reads as context, not an afterthought.
            string subNote = "";
            foreach (var c in steps) if (c.Step == currentStep) { subNote = c.SubmitterNote ?? ""; break; }
            if (!string.IsNullOrWhiteSpace(subNote))
            {
                sb.Append("<div style=\"font-weight:600;font-size:13px;margin-bottom:4px;\">Note from ")
                  .Append(esc(submittedBy)).Append("</div>");
                sb.Append("<div style=\"background:#f0f6fc;border-left:3px solid #0f6cbd;padding:10px 12px;font-size:13px;line-height:1.45;margin-bottom:18px;white-space:pre-wrap;\">")
                  .Append(esc(subNote)).Append("</div>");
            }
            // Prefer real links to the documents; fall back to the neutral notice if they can't be built.
            string docLinks = DocumentLinksHtml(service, tracing, requestId, orgBaseUrl);
            if (!string.IsNullOrEmpty(docLinks)) sb.Append(docLinks);
            else sb.Append("<div style=\"font-size:13px;color:#8a8886;margin-bottom:16px;\">").Append(DocumentsNotice).Append("</div>");

            if (!string.IsNullOrEmpty(orgBaseUrl))
            {
                sb.Append("<div style=\"margin:4px 0 12px;\">");
                sb.Append(HtmlDecisionBtnRow(
                    HtmlDecisionBtn("Approve", orgBaseUrl, appId, requestId, "Approve", currentStep),
                    HtmlDecisionBtn("Request Changes", orgBaseUrl, appId, requestId, "RequestChanges", currentStep),
                    HtmlDecisionBtn("Reject", orgBaseUrl, appId, requestId, "Reject", currentStep)));
                sb.Append("</div>");
            }
            if (!string.IsNullOrEmpty(deepLink))
                sb.Append(TableButton(esc(deepLink), "Open in PAMS"));

            sb.Append("</div></td></tr></table></td></tr></table></div></body></html>");
            return sb.ToString();
        }

        // Builds the AUTHENTICATED action URL: a page (web resource) inside the model-driven app.
        // Because it lives in the app, opening it requires a signed-in Dataverse session, and the
        // page calls pams_ProcessApprovalDecision AS the signed-in user - so identity is verified,
        // not asserted by the URL. We deliberately DO NOT put approverId/step/role/comment in the
        // URL: identity comes from sign-in, and the request/step are derived server-side. Only the
        // request id and which decision travel in the link (both non-sensitive). Replaces the old
        // unauthenticated flow-trigger link (DEF-029).
        private const string ActionWebResourceName = "pams_approvalactionpage";
        private static string BuildActionUrl(string orgBaseUrl, string appId, Guid requestId, string decision, int step)
        {
            if (string.IsNullOrEmpty(orgBaseUrl)) return "";
            // Load the page THROUGH the model-driven app shell so the user is in an authenticated app
            // session and Xrm is available: main.aspx?appid=...&pagetype=webresource&webresourceName=...
            // The page's own params ride in &data=<url-encoded querystring>. Step lets the page detect
            // a stale link (this step already decided) if the email is clicked again. Identity still
            // comes from sign-in, not the URL - DEF-029.
            string inner = "RequestId=" + Uri.EscapeDataString(requestId.ToString())
                         + "&Decision=" + Uri.EscapeDataString(decision ?? "")
                         + "&Step=" + step;
            string url = orgBaseUrl.TrimEnd('/') + "/main.aspx?";
            if (!string.IsNullOrEmpty(appId))
                url += "appid=" + Uri.EscapeDataString(appId) + "&";
            url += "pagetype=webresource&webresourceName=" + Uri.EscapeDataString(ActionWebResourceName)
                 + "&data=" + Uri.EscapeDataString(inner);
            return url;
        }

        // Wraps decision cells in a single table so Word lays them out side by side with real gaps.
        // Word-safe single button. Same reason as HtmlDecisionBtn: older Outlook drops
        // display:inline-block and padding on <a>, leaving a bare underlined link.
        private static string TableButton(string safeHref, string label)
        {
            if (string.IsNullOrEmpty(safeHref)) return "";
            return "<table role=\"presentation\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\"><tr>"
                 + "<td bgcolor=\"#0f6cbd\" style=\"background:#0f6cbd;border-radius:6px;mso-padding-alt:9px 20px;\">"
                 + "<a href=\"" + safeHref + "\" style=\"display:inline-block;padding:9px 20px;color:#ffffff;"
                 + "text-decoration:none;font-size:14px;font-weight:600;font-family:Segoe UI,Segoe,Arial,sans-serif;\">"
                 + System.Security.SecurityElement.Escape(label) + "</a></td></tr></table>";
        }

        // The four file columns on the request, with the labels the form shows for them.
        // Purpose labels shown beside each file. These MIRROR the column display names in Dataverse -
        // the request form doesn't hardcode them, it overwrites its own fallbacks from attribute
        // metadata (applyAttachmentDisplayNames), which is why the form reads "AFE" and "Additional
        // Documentation 1" rather than the older "AFE / Documentation" and "SOW". If a column's
        // display name is changed in the maker portal, update it here too or the email and the form
        // will disagree.
        private static readonly string[][] AttachmentCols = new string[][] {
            new[] { "pams_attachment1",              "AFE" },
            new[] { "pams_attachment2",              "Additional Documentation 1" },
            new[] { "pams_additionaldocumentation2", "Additional Documentation 2" },
            new[] { "pams_additionaldocumentation3", "Additional Documentation 3" }
        };

        // DEF-030: link to the documents instead of claiming they are attached.
        // Attachments are added DOWNSTREAM by the flow, so this plugin cannot know whether they will
        // be delivered - on the oversize path they are silently dropped. Links don't depend on the
        // flow at all: they always work, whatever the flow does with the files.
        //
        // Why a link is viable here when the emailed LOGO was not: the logo is fetched automatically
        // by the mail client, which has no Dataverse session, so an authenticated URL fails silently.
        // These links are clicked BY THE USER, opening in their browser where they normally already
        // have a Dynamics session - and if not, they get a sign-in prompt, which is acceptable for an
        // approval system. Approvers already hold Read on the request via the sharing plugin.
        //
        // Degrades in stages: if the file-name columns aren't readable, retry with the base columns
        // and use the business labels; if that fails too, return "" and the caller falls back to the
        // neutral DocumentsNotice.
        private static string DocumentLinksHtml(IOrganizationService service, ITracingService tracing,
                                                Guid requestId, string orgBaseUrl)
        {
            if (string.IsNullOrEmpty(orgBaseUrl) || requestId == Guid.Empty) return "";
            Entity rec = null;
            bool haveNames = true;
            try
            {
                var cols = new List<string>();
                foreach (var c in AttachmentCols) { cols.Add(c[0]); cols.Add(c[0] + "_name"); }
                rec = service.Retrieve(EntityRequest, requestId, new ColumnSet(cols.ToArray()));
            }
            catch (Exception ex)
            {
                // "_name" may not be a retrievable attribute in this org/SDK version.
                if (tracing != null) tracing.Trace("Document links: name columns unavailable ({0}); retrying without.", ex.Message);
                haveNames = false;
                try
                {
                    var baseCols = new List<string>();
                    foreach (var c in AttachmentCols) baseCols.Add(c[0]);
                    rec = service.Retrieve(EntityRequest, requestId, new ColumnSet(baseCols.ToArray()));
                }
                catch (Exception ex2)
                {
                    if (tracing != null) tracing.Trace("Document links unavailable (non-fatal): {0}", ex2.Message);
                    return "";
                }
            }
            if (rec == null) return "";

            string apiBase = orgBaseUrl.TrimEnd('/') + "/api/data/v9.2/" + EntitySetRequest + "(" + requestId + ")/";
            var rows = new StringBuilder();
            int found = 0;
            foreach (var c in AttachmentCols)
            {
                // A file column reads as empty when no file is present.
                object raw = rec.Contains(c[0]) ? rec[c[0]] : null;
                if (raw == null || string.IsNullOrWhiteSpace(raw.ToString())) continue;

                string fileName = haveNames ? rec.GetAttributeValue<string>(c[0] + "_name") : null;
                string url = apiBase + c[0] + "/$value";
                found++;

                // "3. testfile3.xlsx (Additional Documentation 2)" - the FILE NAME is the link; the
                // purpose in parentheses is plain text. Numbered manually rather than with <ol>,
                // which older Outlook (Word rendering) indents unpredictably.
                rows.Append("<div style=\"margin:3px 0;\">")
                    .Append(found).Append(". ")
                    .Append("<a href=\"").Append(System.Security.SecurityElement.Escape(url))
                    .Append("\" style=\"color:#0f6cbd;text-decoration:underline;\">")
                    // No filename available (the _name column wasn't readable) - link the purpose
                    // instead, so the row is still actionable, and skip the redundant parenthetical.
                    .Append(System.Security.SecurityElement.Escape(
                        string.IsNullOrWhiteSpace(fileName) ? c[1] : fileName))
                    .Append("</a>");
                if (!string.IsNullOrWhiteSpace(fileName))
                    rows.Append(" <span style=\"color:#605e5c;\">(")
                        .Append(System.Security.SecurityElement.Escape(c[1]))
                        .Append(")</span>");
                rows.Append("</div>");
            }
            if (found == 0) return "";

            var sb = new StringBuilder(1024);
            // Same heading treatment as "Approval Progress" - the top rule doubles as the separator
            // between the two sections, so they read as siblings rather than a list bolted on.
            sb.Append("<div style=\"font-size:13px;margin-bottom:16px;\">");
            sb.Append("<div style=\"font-weight:700;font-size:15px;border-top:1px solid #edebe9;padding-top:14px;margin-bottom:8px;\">Attachments (").Append(found).Append(")</div>");
            sb.Append(rows);
            sb.Append("</div>");
            return sb.ToString();
        }

        // DEF-030: never assert that documents are attached to the email.
        // Attachments are added DOWNSTREAM by the Power Automate flow, AFTER this body is written,
        // so at this point the plugin cannot know whether they will be delivered. On the oversize
        // path the flow drops them and the approver previously received
        //     "The AFE and supporting documents are attached to this email."
        // with nothing attached and no notice - they could approve without ever seeing the AFE.
        // (Note the related retraction: "Attachments (0)" on the Dataverse email record is NORMAL,
        // because the flow adds them later. It is not a defect signal.)
        // This wording is true whether or not the files arrive, and always gives the approver a way
        // to reach them. When attachments DO come through, the mail client shows them anyway - the
        // body does not need to announce it.
        // A definitive "these documents could not be attached" notice can only come from the FLOW,
        // which is the only component that knows the outcome. That remains outstanding.
        private const string DocumentsNotice =
            "The AFE and supporting documents can be viewed on the request in PAMS.";

        private static string HtmlDecisionBtnRow(params string[] cells)
        {
            var kept = new List<string>();
            foreach (var c in cells) if (!string.IsNullOrEmpty(c)) kept.Add(c);
            if (kept.Count == 0) return "";
            var sb = new StringBuilder(1024);
            sb.Append("<table role=\"presentation\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"border-collapse:separate;\"><tr>");
            for (int i = 0; i < kept.Count; i++)
            {
                if (i > 0) sb.Append("<td width=\"10\" style=\"width:10px;font-size:0;line-height:0;\">&nbsp;</td>");
                sb.Append(kept[i]);
            }
            sb.Append("</tr></table>");
            return sb.ToString();
        }

        private static string HtmlDecisionBtn(string label, string orgBaseUrl, string appId, Guid requestId, string decision, int step)
        {
            string url = BuildActionUrl(orgBaseUrl, appId, requestId, decision, step);
            if (string.IsNullOrEmpty(url)) return "";
            string safe = System.Security.SecurityElement.Escape(url);
            // Returns a <td>, not an <a>. Older Outlook renders HTML through Word, which ignores
            // display:inline-block and CSS padding on inline elements - that collapsed all three
            // buttons into one run of underlined text ("ApproveRequest ChangesReject"). A table cell
            // with bgcolor + mso-padding-alt is the shape Word actually honours, and cells keep the
            // buttons side by side. Wrapped by HtmlDecisionBtnRow.
            return "<td bgcolor=\"#0f6cbd\" style=\"background:#0f6cbd;border-radius:6px;mso-padding-alt:9px 18px;\">"
                 + "<a href=\"" + safe + "\" style=\"display:inline-block;padding:9px 18px;color:#ffffff;"
                 + "text-decoration:none;font-size:14px;font-weight:600;font-family:Segoe UI,Segoe,Arial,sans-serif;\">"
                 + System.Security.SecurityElement.Escape(label) + "</a></td>";
        }

        // Returns the systemuser flagged as the primary administrator (pams_primaryadministrator =
        // true), active only. If more than one is flagged, the first is used. Null if none found.
        private static EntityReference FindPrimaryAdministrator(IOrganizationService service, ITracingService tracing)
        {
            try
            {
                var q = new QueryExpression("systemuser")
                {
                    ColumnSet = new ColumnSet("systemuserid", "fullname"),
                    TopCount = 1
                };
                q.Criteria.AddCondition("pams_primaryadministrator", ConditionOperator.Equal, true);
                q.Criteria.AddCondition("isdisabled", ConditionOperator.Equal, false);
                var res = service.RetrieveMultiple(q);
                if (res.Entities.Count == 0) { tracing.Trace("No primary administrator flagged."); return null; }
                var u = res.Entities[0];
                return new EntityReference("systemuser", u.Id) { Name = u.GetAttributeValue<string>("fullname") };
            }
            catch (Exception ex)
            {
                tracing.Trace("FindPrimaryAdministrator failed (non-fatal): {0}", ex.Message);
                return null;
            }
        }

        // Notifies every member of the PAMS - Administrators team that a request has reached
        // Pending Project Setup and needs their setup. One email, To = all active admin members.
        // Uses the shared PAMS subject prefix so the existing flow sends it. Non-fatal on error.
        // Active members of the admin team flagged as PRIMARY administrator. Same source of truth
        // the setup email uses to pick its addressee, so "primary admin" means one thing in both.
        private static List<Guid> GetPrimaryAdminIds(IOrganizationService service, ITracingService tracing)
        {
            var ids = new List<Guid>();
            try
            {
                var teamQ = new QueryExpression("team") { ColumnSet = new ColumnSet("teamid"), Criteria = new FilterExpression() };
                teamQ.Criteria.AddCondition("name", ConditionOperator.Equal, AdminTeamName);
                var teams = service.RetrieveMultiple(teamQ);
                if (teams.Entities.Count == 0)
                {
                    if (tracing != null) tracing.Trace("GetPrimaryAdminIds: {0} team not found.", AdminTeamName);
                    return ids;
                }
                var memberQ = new QueryExpression("systemuser") { ColumnSet = new ColumnSet("systemuserid", "isdisabled", "pams_primaryadministrator") };
                var link = memberQ.AddLink("teammembership", "systemuserid", "systemuserid", JoinOperator.Inner);
                link.LinkCriteria.AddCondition("teamid", ConditionOperator.Equal, teams.Entities[0].Id);
                foreach (var u in service.RetrieveMultiple(memberQ).Entities)
                {
                    if (u.GetAttributeValue<bool>("isdisabled")) continue;
                    if (u.GetAttributeValue<bool>("pams_primaryadministrator")) ids.Add(u.Id);
                }
            }
            catch (Exception ex)
            {
                // Never fail an email over the CC lookup - send without it.
                if (tracing != null) tracing.Trace("GetPrimaryAdminIds failed (non-fatal): {0}", ex.Message);
            }
            return ids;
        }

        /// <summary>
        /// Is this user's watcher row DERIVED FROM THE CHAIN (source = Approver), as opposed to
        /// having been put there by a person or another process?
        ///
        /// Only chain-derived rows lose access when the chain changes. A Manual row survives -
        /// somebody chose to add them, and that choice outlives their time on a step. Rows with no
        /// source (created before the column existed) fall back to pams_ismanual, so historical
        /// data behaves the same way.
        ///
        /// Returns false when the row can't be read: the safe direction is to KEEP access rather
        /// than revoke it on a failed lookup.
        /// </summary>
        /// <summary>Named approver plus any backups on a step, as raw id strings.</summary>
        private static IEnumerable<string> ChainStepPrincipals(ChainStep st)
        {
            if (st == null) yield break;
            if (!string.IsNullOrWhiteSpace(st.ApproverId)) yield return st.ApproverId;
            if (st.OtherValidApproverIds != null)
                foreach (var o in st.OtherValidApproverIds)
                    if (!string.IsNullOrWhiteSpace(o)) yield return o;
        }

        /// <summary>
        /// The access level a user's position in the chain justifies:
        ///   WRITE - they are the named approver or a backup on the CURRENT step, so the decision
        ///           is sitting with them and they may edit req 56's fields (reqs 58, 60);
        ///   READ  - they appear elsewhere in the chain;
        ///   READ  - they appear nowhere (callers decide separately whether to revoke instead).
        ///
        /// Takes the HIGHEST level across all their positions. One person commonly occupies several
        /// steps, and asking about a single step gives the wrong answer for the others.
        /// Setup steps are excluded: that assignee is an admin, not an approver.
        /// </summary>
        private static int LevelForChainPosition(List<ChainStep> chain, int currentStep, Guid userId)
        {
            if (chain == null || userId == Guid.Empty) return AccessLevelRead;
            int level = AccessLevelRead;
            foreach (var st in chain)
            {
                if (st == null || st.IsSetup) continue;

                bool isThem = false;
                Guid id;
                if (!string.IsNullOrWhiteSpace(st.ApproverId)
                    && Guid.TryParse(st.ApproverId.Replace("{", "").Replace("}", ""), out id) && id == userId)
                    isThem = true;
                if (!isThem && st.OtherValidApproverIds != null)
                    foreach (var o in st.OtherValidApproverIds)
                        if (!string.IsNullOrWhiteSpace(o)
                            && Guid.TryParse(o.Replace("{", "").Replace("}", ""), out id) && id == userId)
                        { isThem = true; break; }

                if (isThem && st.Step == currentStep) return AccessLevelWrite;   // highest possible
            }
            return level;
        }

        /// <summary>
        /// Does this user already reach the request WITHOUT a share - as its owner, its project
        /// manager, or its creator?
        ///
        /// These are exactly the three a watcher row is refused for, so sharing with them grants
        /// access they already hold and leaves a share nothing will clean up (for the owner,
        /// Dataverse actively refuses to revoke it).
        ///
        /// Returns FALSE if the request can't be read: on a failed lookup the safe direction is to
        /// proceed, since a surplus share is recoverable while a missing one strands an approver.
        /// </summary>
        private static bool IsAccessInherent(IOrganizationService service, ITracingService tracing,
                                             Guid requestId, Guid userId)
        {
            try
            {
                var req = service.Retrieve(EntityRequest, requestId,
                    new ColumnSet("ownerid", FieldProjectManager, FieldCreatedBy));
                foreach (var f in new[] { "ownerid", FieldProjectManager, FieldCreatedBy })
                {
                    var r = req.GetAttributeValue<EntityReference>(f);
                    if (r != null && r.Id == userId) return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                tracing.Trace("Inherent-access check failed ({0}); proceeding.", ex.Message);
                return false;
            }
        }

        private static bool WatcherRowIsChainDerived(IOrganizationService service, ITracingService tracing,
                                                     Guid requestId, Guid userId)
        {
            try
            {
                var q = new QueryExpression(EntityWatcher)
                {
                    ColumnSet = new ColumnSet("pams_watchersource", "pams_ismanual"),
                    TopCount = 1,
                    Criteria = new FilterExpression(LogicalOperator.And)
                };
                q.Criteria.AddCondition("pams_requestid", ConditionOperator.Equal, requestId);
                q.Criteria.AddCondition("pams_watcherid", ConditionOperator.Equal, userId);
                var rows = service.RetrieveMultiple(q).Entities;
                if (rows.Count == 0) return true;   // no row to protect

                var src = rows[0].GetAttributeValue<OptionSetValue>("pams_watchersource");
                if (src != null) return src.Value == WatcherSourceApprover;
                return !rows[0].GetAttributeValue<bool>("pams_ismanual");   // legacy rows
            }
            catch (Exception ex)
            {
                tracing.Trace("Watcher provenance lookup failed ({0}); keeping access.", ex.Message);
                return false;
            }
        }

        /// <summary>
        /// Sets one principal's share on the request to exactly `level`, and records the intent on
        /// their watcher row.
        ///
        /// Used to hand WRITE from the outgoing approver to the incoming one as the chain advances,
        /// which is reqs 58/60 ("only when it's their turn", "once approved they cannot edit")
        /// enforced by the platform rather than only by the form.
        ///
        /// ModifyAccess rather than Grant: Grant is ADDITIVE, so an approver who has finished
        /// their step would keep Write forever if we only ever granted. Modify sets the mask to
        /// exactly this value.
        ///
        /// Skips the record owner - Dataverse refuses to modify the owner's access, and their
        /// access comes from ownership anyway.
        /// Non-fatal: a share adjustment must never roll back a decision the user already made.
        /// </summary>
        private static void SetWatcherAccess(IOrganizationService systemService, ITracingService tracing,
                                             Guid requestId, Guid userId, int level)
        {
            if (userId == Guid.Empty) return;
            try
            {
                // Never share with someone whose access does not come from a share.
                //
                // This checked the OWNER only, which is not the same set. On a normal request the
                // owner is the LOCATION TEAM, so the project manager and the creator did not match
                // - and setting an outgoing approver to "Read" would then CREATE a share for the PM
                // on their own request. No watcher row exists to stamp, so it never appeared in the
                // watcher list; it just sat in PrincipalObjectAccess.
                //
                // Same rule as the row-creation guard (WhyNotAWatcher in RequestWatcherSharing):
                // if a person may not have a watcher ROW, they must not get a SHARE either.
                if (IsAccessInherent(systemService, tracing, requestId, userId))
                {
                    tracing.Trace("User {0} owns/manages/created request {1}; no share needed.", userId, requestId);
                    return;
                }

                var target = new EntityReference(EntityRequest, requestId);
                var principal = new EntityReference("systemuser", userId);

                if (level == AccessLevelNone || level == AccessLevelRevoked)
                {
                    systemService.Execute(new RevokeAccessRequest { Target = target, Revokee = principal });
                }
                else
                {
                    var mask = level == AccessLevelWrite
                        ? (AccessRights.ReadAccess | AccessRights.WriteAccess)
                        : AccessRights.ReadAccess;
                    systemService.Execute(new ModifyAccessRequest
                    {
                        Target = target,
                        PrincipalAccess = new PrincipalAccess { Principal = principal, AccessMask = mask }
                    });
                }

                // Mirror the intent onto the watcher row so the state stays queryable.
                var q = new QueryExpression(EntityWatcher)
                {
                    ColumnSet = new ColumnSet("pams_requestwatcherid"),
                    TopCount = 1,
                    Criteria = new FilterExpression(LogicalOperator.And)
                };
                q.Criteria.AddCondition("pams_requestid", ConditionOperator.Equal, requestId);
                q.Criteria.AddCondition("pams_watcherid", ConditionOperator.Equal, userId);
                var rows = systemService.RetrieveMultiple(q).Entities;
                if (rows.Count > 0)
                    systemService.Update(new Entity(EntityWatcher, rows[0].Id)
                    {
                        ["pams_accesslevel"] = new OptionSetValue(level)
                    });

                tracing.Trace("Access for {0} on {1} set to {2}.", userId, requestId, level);
            }
            catch (Exception ex)
            {
                tracing.Trace("SetWatcherAccess failed (non-fatal): {0}", ex.Message);
            }
        }

        /// <summary>SYSTEM service - RevokeAccess needs prvShare, which users no longer hold.</summary>
        private static IOrganizationService systemServiceForShares(IOrganizationServiceFactory factory)
        {
            return factory.CreateOrganizationService(null);
        }

        /// <summary>
        /// Revokes every watcher's share on a request, leaving the watcher ROWS intact.
        ///
        /// Skips the project manager. That is defensive rather than load-bearing: the PM picker
        /// only offers members of the owning location team, so the PM normally retains access
        /// through team ownership anyway. But a PM set outside the overlay (native form, import,
        /// migration) might not be in that team, and revoking there would lock them out of their
        /// own request permanently - unable to see it, resubmit it, or ask for it back.
        ///
        /// Non-fatal throughout: a failed revoke must never roll back the cancel the user asked
        /// for, and the worst case is a stale share on a dead request.
        /// </summary>
        private static void RevokeAllWatcherShares(IOrganizationService systemService, ITracingService tracing,
                                                   Guid requestId, EntityReference keepAccessFor)
        {
            try
            {
                var q = new QueryExpression(EntityWatcher)
                {
                    ColumnSet = new ColumnSet("pams_watcherid"),
                    Criteria = new FilterExpression()
                };
                q.Criteria.AddCondition("pams_requestid", ConditionOperator.Equal, requestId);
                var rows = systemService.RetrieveMultiple(q).Entities;

                var target = new EntityReference(EntityRequest, requestId);
                var owner = OwnerOf(systemService, tracing, requestId);
                int revoked = 0, skipped = 0;

                foreach (var row in rows)
                {
                    var w = row.GetAttributeValue<EntityReference>("pams_watcherid");
                    if (w == null || w.Id == Guid.Empty) continue;
                    if (keepAccessFor != null && w.Id == keepAccessFor.Id) { skipped++; continue; }
                    // Dataverse refuses to revoke from the record's owner, even as SYSTEM.
                    if (owner != null && owner.Id == w.Id) { skipped++; continue; }
                    try
                    {
                        systemService.Execute(new RevokeAccessRequest { Target = target, Revokee = w });
                        try
                        {
                            systemService.Update(new Entity(EntityWatcher, row.Id)
                            {
                                ["pams_accesslevel"] = new OptionSetValue(AccessLevelNone)
                            });
                        }
                        catch (Exception uex)
                        {
                            tracing.Trace("Access-level stamp for {0} failed (non-fatal): {1}", w.Id, uex.Message);
                        }
                        revoked++;
                    }
                    catch (Exception rex)
                    {
                        tracing.Trace("Revoke for watcher {0} failed (non-fatal): {1}", w.Id, rex.Message);
                    }
                }
                tracing.Trace("Cancel: revoked {0} watcher share(s) on {1}, kept {2}.", revoked, requestId, skipped);
            }
            catch (Exception ex)
            {
                tracing.Trace("RevokeAllWatcherShares failed (non-fatal): {0}", ex.Message);
            }
        }

        private static EntityReference OwnerOf(IOrganizationService service, ITracingService tracing, Guid requestId)
        {
            try
            {
                return service.Retrieve(EntityRequest, requestId, new ColumnSet("ownerid"))
                              .GetAttributeValue<EntityReference>("ownerid");
            }
            catch (Exception ex)
            {
                tracing.Trace("Owner lookup failed ({0}).", ex.Message);
                return null;
            }
        }

        // Is this user already an activityparty in the given list? Used to avoid adding someone to
        // CC who is already on To (e.g. a project manager who is also an administrator).
        /// <summary>
        /// The person who SUBMITTED the request, which is NOT necessarily its project manager.
        ///
        /// Every decision email resolved one recipient as "pams_projectmanager ?? createdby" - a
        /// FALLBACK, not a union. Req 7.3 defaults the PM to the submitter, so the two usually
        /// match and the gap stayed hidden; but an administrator submitting on someone's behalf,
        /// or an approver reassigning the PM under req 56.3, leaves the actual submitter with no
        /// notification at all. They would not learn their own request had been approved,
        /// rejected, returned or cancelled.
        /// </summary>
        private static Guid RequesterId(Entity req)
        {
            var creator = req.GetAttributeValue<EntityReference>(FieldCreatedBy);
            return creator == null ? Guid.Empty : creator.Id;
        }

        /// <summary>
        /// Adds a CC recipient unless they are already on the To or Cc list. Returns true if added.
        /// Deduping matters here because the submitter IS the PM in the common case, and listing
        /// the same person twice looks like a defect to the recipient.
        /// </summary>
        private static bool AddCcIfNew(List<Entity> toParties, List<Entity> ccParties, Guid userId)
        {
            if (userId == Guid.Empty) return false;
            if (PartyListHas(toParties, userId) || PartyListHas(ccParties, userId)) return false;
            var p = new Entity("activityparty");
            p["partyid"] = new EntityReference("systemuser", userId);
            ccParties.Add(p);
            return true;
        }

        private static bool PartyListHas(List<Entity> parties, Guid userId)
        {
            if (parties == null || userId == Guid.Empty) return false;
            foreach (var p in parties)
            {
                var er = p.Contains("partyid") ? p["partyid"] as EntityReference : null;
                if (er != null && er.Id == userId) return true;
            }
            return false;
        }

        private static void LogAdminSetupEmail(IOrganizationService service, ITracingService tracing,
            Entity req, Guid requestId, string title, string identifier, Guid fromUserId,
            string orgBaseUrl, string linkUrl)
        {
            try
            {
                var teamQ = new QueryExpression("team") { ColumnSet = new ColumnSet("teamid"), Criteria = new FilterExpression() };
                teamQ.Criteria.AddCondition("name", ConditionOperator.Equal, AdminTeamName);
                var teams = service.RetrieveMultiple(teamQ);
                if (teams.Entities.Count == 0) { tracing.Trace("LogAdminSetupEmail: {0} team not found.", AdminTeamName); return; }
                Guid teamId = teams.Entities[0].Id;

                var memberQ = new QueryExpression("systemuser") { ColumnSet = new ColumnSet("systemuserid", "isdisabled", "pams_primaryadministrator") };
                var link = memberQ.AddLink("teammembership", "systemuserid", "systemuserid", JoinOperator.Inner);
                link.LinkCriteria.AddCondition("teamid", ConditionOperator.Equal, teamId);
                var members = service.RetrieveMultiple(memberQ);

                // The PRIMARY administrator (the setup owner) goes on To; every other active admin is
                // CC'd so the team is informed without being the addressee. If no primary is flagged,
                // fall back to putting all active admins on To so the email still reaches someone.
                var primaryParties = new List<Entity>();
                var ccParties = new List<Entity>();
                var allActive = new List<Entity>();
                foreach (var u in members.Entities)
                {
                    if (u.GetAttributeValue<bool>("isdisabled")) continue;
                    var p = new Entity("activityparty");
                    p["partyid"] = new EntityReference("systemuser", u.Id);
                    allActive.Add(p);
                    if (u.GetAttributeValue<bool>("pams_primaryadministrator")) primaryParties.Add(p);
                    else ccParties.Add(p);
                }
                if (allActive.Count == 0) { tracing.Trace("LogAdminSetupEmail: no active admin members."); return; }

                List<Entity> toParties;
                if (primaryParties.Count > 0)
                {
                    toParties = primaryParties;        // primary addressed directly
                    // ccParties already holds every active non-primary admin
                }
                else
                {
                    // No primary flagged: address all active admins, no CC.
                    tracing.Trace("LogAdminSetupEmail: no primary flagged; addressing all active admins.");
                    toParties = allActive;
                    ccParties = new List<Entity>();
                }

                // CC the Project Manager. Their request is what just became fully approved, so they
                // need to know it has moved into setup - but the addressee is the admin who does the
                // work, hence CC rather than To. Same PM resolution used everywhere else: the
                // explicit Project Manager lookup, falling back to the record creator.
                var pmRef = req.GetAttributeValue<EntityReference>(FieldProjectManager)
                            ?? req.GetAttributeValue<EntityReference>(FieldCreatedBy);
                if (pmRef != null && pmRef.Id != Guid.Empty)
                {
                    // A PM who is also an administrator is already a recipient - don't list them twice.
                    if (PartyListHas(toParties, pmRef.Id) || PartyListHas(ccParties, pmRef.Id))
                        tracing.Trace("LogAdminSetupEmail: PM {0} is already a recipient; not added again.", pmRef.Id);
                    else
                    {
                        var pmParty = new Entity("activityparty");
                        pmParty["partyid"] = new EntityReference("systemuser", pmRef.Id);
                        ccParties.Add(pmParty);
                        tracing.Trace("LogAdminSetupEmail: CC'd project manager {0}.", pmRef.Id);
                    }
                }

                // ...and the SUBMITTER too, when they are not the PM. Their request has cleared
                // every approval and is now waiting on administrative setup; they should hear that
                // from PAMS rather than by checking.
                if (AddCcIfNew(toParties, ccParties, RequesterId(req)))
                    tracing.Trace("LogAdminSetupEmail: CC'd the submitter (not the project manager).");

                string location = "";
                var locRef = req.GetAttributeValue<EntityReference>(FieldLocation);
                if (locRef != null) location = locRef.Name ?? "";
                string projectType = CardFormatted(req, FieldProjectType);
                string deepLink = string.IsNullOrEmpty(orgBaseUrl) ? (linkUrl ?? "")
                    : (orgBaseUrl + "/main.aspx?pagetype=entityrecord&etn=" + EntityRequest + "&id=" + requestId);

                var email = new Entity("email");
                email["subject"] = "PAMS Project Approval Request - " + title + " - Pending Project Setup";
                email["description"] = BuildAdminSetupCardHtml(service, tracing, title, identifier, location, projectType, deepLink);
                email["directioncode"] = true;
                email["regardingobjectid"] = new EntityReference(EntityRequest, requestId);
                // From = the approver whose final approval triggered this, so the email record
                // shows who it came from rather than being blank.
                if (fromUserId != Guid.Empty)
                {
                    var from = new Entity("activityparty");
                    from["partyid"] = new EntityReference("systemuser", fromUserId);
                    email["from"] = new EntityCollection(new List<Entity> { from }) { EntityName = "activityparty" };
                }
                email["to"] = new EntityCollection(toParties) { EntityName = "activityparty" };
                if (ccParties.Count > 0)
                    email["cc"] = new EntityCollection(ccParties) { EntityName = "activityparty" };

                Guid emailId = service.Create(email);
                var setState = new OrganizationRequest("SetState");
                setState["EntityMoniker"] = new EntityReference("email", emailId);
                setState["State"] = new OptionSetValue(1);
                setState["Status"] = new OptionSetValue(3);
                service.Execute(setState);
            }
            catch (Exception ex)
            {
                tracing.Trace("LogAdminSetupEmail failed (non-fatal): {0}", ex.Message);
            }
        }

        // ---- shared branded email shell ---------------------------------------
        // Single source of truth for the look of every PAMS email. Previously each builder
        // hand-rolled its own <body>, so BuildAdminSetupCardHtml and BuildReturnCardHtml drifted
        // into bare <p>+<table>+raw-link while the others stayed branded. Since the adaptive card
        // is what Outlook DISCARDS when it can't render it (see the missing "originator" property),
        // this HTML is what recipients actually see - it has to carry the branding.
        private static string Esc(string s)
        {
            return System.Security.SecurityElement.Escape(s ?? "");
        }

        // factsHtml / introHtml / extraHtml are pre-built, already-escaped HTML fragments.
        // cardJson may be null or empty, in which case no adaptive-card script tag is emitted.
        // deepLink may be null or empty, in which case no button is emitted.
        private static string BrandedShell(string cardJson, string logo, string title,
            string statusText, string statusColor, string introHtml, string factsHtml,
            string extraHtml, string deepLink)
        {
            var sb = new StringBuilder(4096);
            sb.Append("<html><head>");
            if (!string.IsNullOrEmpty(cardJson))
                sb.Append("<script type=\"application/adaptivecard+json\">").Append(cardJson).Append("</script>");
            sb.Append("</head>");
            sb.Append("<body style=\"font-family:Segoe UI,Segoe,Arial,sans-serif;margin:0;padding:0;color:#201f1e;\">");
            sb.Append("<div style=\"font-family:Segoe UI,Segoe,Arial,sans-serif;background:#f3f2f1;padding:32px 16px;color:#201f1e;\">");
            // DEF-051: legacy Outlook renders HTML through WORD, which ignores max-width, margin:0 auto,
            // border-radius and box-shadow. The card therefore stretched to the full window width on
            // a wide monitor. A table with a real width attribute is the one layout primitive Word
            // honours, so the 600px column holds everywhere. border-radius / box-shadow are left on
            // the inner div: modern clients round the corners, Word just draws them square, which is
            // cosmetic degradation rather than a broken layout.
            sb.Append("<table role=\"presentation\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\"><tr><td align=\"center\">");
            sb.Append("<table role=\"presentation\" width=\"600\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"width:600px;max-width:600px;\"><tr><td>");
            sb.Append("<div style=\"background:#fff;border:1px solid #e1dfdd;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,.06);overflow:hidden;\">");
            if (!string.IsNullOrEmpty(logo))
                sb.Append("<div style=\"text-align:center;padding:26px 24px 8px;\"><img src=\"").Append(logo)
                  .Append("\" alt=\"Morton Salt\" width=\"190\" style=\"width:190px;max-width:190px;height:auto;border:0;display:inline-block;\" /></div>");
            sb.Append("<div style=\"padding:8px 32px 32px;\">");
            sb.Append("<div style=\"font-size:13px;letter-spacing:.04em;text-transform:uppercase;color:#8a8886;font-weight:600;\">PAMS Project Approval Request</div>");
            sb.Append("<h1 style=\"font-size:26px;margin:2px 0 10px;font-weight:700;\">").Append(Esc(title)).Append("</h1>");
            if (!string.IsNullOrEmpty(statusText))
                sb.Append("<div style=\"color:").Append(string.IsNullOrEmpty(statusColor) ? "#0f6cbd" : statusColor)
                  .Append(";font-weight:600;font-size:15px;margin-bottom:14px;\">").Append(Esc(statusText)).Append("</div>");
            if (!string.IsNullOrEmpty(introHtml))
                sb.Append("<div style=\"font-size:14px;line-height:1.5;margin-bottom:18px;\">").Append(introHtml).Append("</div>");
            if (!string.IsNullOrEmpty(factsHtml))
                sb.Append("<table style=\"border-collapse:collapse;font-size:14px;margin-bottom:20px;\">").Append(factsHtml).Append("</table>");
            if (!string.IsNullOrEmpty(extraHtml))
                sb.Append(extraHtml);
            if (!string.IsNullOrEmpty(deepLink))
                sb.Append(TableButton(Esc(deepLink), "Open in PAMS"));
            sb.Append("</div></td></tr></table></td></tr></table></div></body></html>");
            return sb.ToString();
        }

        // A quoted block (approver comment, cancellation reason) in the shared style.
        private static string BrandedQuote(string heading, string body, string accent)
        {
            if (string.IsNullOrWhiteSpace(body)) return "";
            var sb = new StringBuilder(512);
            if (!string.IsNullOrEmpty(heading))
                sb.Append("<div style=\"font-weight:600;font-size:13px;margin-bottom:4px;\">").Append(Esc(heading)).Append("</div>");
            sb.Append("<div style=\"background:#faf9f8;border-left:3px solid ").Append(string.IsNullOrEmpty(accent) ? "#c8c6c4" : accent)
              .Append(";padding:10px 12px;font-size:13px;line-height:1.45;margin-bottom:20px;white-space:pre-wrap;\">")
              .Append(Esc(body)).Append("</div>");
            return sb.ToString();
        }

        private static string BuildAdminSetupCardHtml(IOrganizationService service, ITracingService tracing, string title, string identifier, string location,
            string projectType, string deepLink)
        {
            var card = new StringBuilder();
            card.Append("{\"type\":\"AdaptiveCard\",\"$schema\":\"http://adaptivecards.io/schemas/adaptive-card.json\",\"version\":\"1.6\",");
            card.Append("\"body\":[");
            string aLogo = LogoFromDeepLink(service, tracing, deepLink);
            if (!string.IsNullOrEmpty(aLogo))
                card.Append("{\"type\":\"Image\",\"url\":").Append(J(aLogo)).Append(",\"horizontalAlignment\":\"Center\",\"width\":\"190px\",\"spacing\":\"None\",\"altText\":\"Morton Salt\"},");
            card.Append("{\"type\":\"TextBlock\",\"size\":\"Medium\",\"weight\":\"Bolder\",\"text\":\"A request is ready for project setup\"},");
            card.Append("{\"type\":\"TextBlock\",\"size\":\"Large\",\"weight\":\"Bolder\",\"spacing\":\"None\",\"wrap\":true,\"text\":").Append(J(title)).Append("},");
            card.Append("{\"type\":\"TextBlock\",\"weight\":\"Bolder\",\"color\":\"Good\",\"wrap\":true,\"text\":\"Awaiting Project Setup\"},");
            card.Append("{\"type\":\"FactSet\",\"separator\":true,\"spacing\":\"Medium\",\"facts\":[");
            card.Append("{\"title\":\"Project Title:\",\"value\":").Append(J(title)).Append("},");
            card.Append("{\"title\":\"Project ID:\",\"value\":").Append(J(identifier)).Append("},");
            card.Append("{\"title\":\"Location:\",\"value\":").Append(J(location)).Append("},");
            card.Append("{\"title\":\"Project Type:\",\"value\":").Append(J(projectType)).Append("}");
            card.Append("]}");
            card.Append("]");
            if (!string.IsNullOrEmpty(deepLink))
                card.Append(",\"actions\":[{\"type\":\"Action.OpenUrl\",\"title\":\"Open in PAMS\",\"url\":").Append(J(deepLink)).Append("}]");
            card.Append("}");

            string facts = HtmlFactRow("Project ID:", identifier)
                         + HtmlFactRow("Location:", location)
                         + HtmlFactRow("Project Type:", projectType);
            string intro = "This request is fully approved and is now waiting on project setup.";
            return BrandedShell(card.ToString(), aLogo, title, "Awaiting Project Setup", "#107c10",
                                intro, facts, null, deepLink);
        }

        // Logs a Dataverse email activity notifying the PM (request creator) that an approver
        // requested changes, including the approver's comment. From = the approver (caller),
        // To = the PM. Regarding the request. Subject uses the shared PAMS prefix so the same
        // DEF-006: tells the PM the lifecycle is finished and gives them the assigned Project
        // Number. Previously the request simply went quiet after setup. Non-fatal.
        private static void LogSetupCompleteEmail(IOrganizationService service, ITracingService tracing,
            Entity req, Guid requestId, string title, string identifier,
            string projectNumber, Guid pmId, Guid fromUserId, string orgBaseUrl, string linkUrl)
        {
            try
            {
                string location = CardFormatted(req, FieldLocation);
                string projectType = CardFormatted(req, FieldProjectType);
                string deepLink = string.IsNullOrEmpty(orgBaseUrl) ? (linkUrl ?? "")
                    : (orgBaseUrl + "/main.aspx?pagetype=entityrecord&etn=" + EntityRequest + "&id=" + requestId);
                string logo = LogoFromDeepLink(service, tracing, deepLink);

                string facts = HtmlFactRow("Project ID:", identifier)
                             + HtmlFactRow("Location:", location)
                             + HtmlFactRow("Project Type:", projectType);
                // The assigned Project Number is the point of this email, so it rides with the
                // intro block rather than being buried under the fact table.
                string intro = "Your request is fully approved and set up. It has been assigned the Project Number below - no further action is needed."
                             + "<div style=\"background:#f3f9f1;border:1px solid #c8e6c0;border-radius:6px;padding:12px 14px;margin:14px 0 0;\">"
                             + "<div style=\"font-size:12px;color:#605e5c;margin-bottom:2px;\">Project Number</div>"
                             + "<div style=\"font-size:20px;font-weight:700;\">" + Esc(projectNumber) + "</div></div>";
                string html = BrandedShell(null, logo, title, "Project setup is complete", "#107c10",
                                           intro, facts, null, deepLink);

                var email = new Entity("email");
                email["subject"] = "PAMS Project Approval Request - " + title + " - Project Setup Complete";
                email["description"] = html;
                email["directioncode"] = true;
                email["regardingobjectid"] = new EntityReference(EntityRequest, requestId);
                // From = the user whose action generated this notification, so the email record
                // shows who it came from rather than being blank.
                if (fromUserId != Guid.Empty)
                {
                    var from = new Entity("activityparty");
                    from["partyid"] = new EntityReference("systemuser", fromUserId);
                    email["from"] = new EntityCollection(new List<Entity> { from }) { EntityName = "activityparty" };
                }

                var to = new Entity("activityparty");
                to["partyid"] = new EntityReference("systemuser", pmId);
                var toParties = new List<Entity> { to };
                email["to"] = new EntityCollection(toParties) { EntityName = "activityparty" };

                // CC the primary administrator. They own Project Setup, so they want the record that
                // it completed - but the PM stays the addressee, since the assigned Project Number is
                // the point of the message.
                var ccParties = new List<Entity>();
                // CC the SUBMITTER when they are not the PM. This is the "your request was
                // approved" message - the outcome the person who raised it has been waiting on -
                // and the To line resolves to the project manager, so a submitter who is not the
                // PM heard nothing about their own request.
                if (AddCcIfNew(toParties, ccParties, RequesterId(req)))
                    tracing.Trace("LogSetupCompleteEmail: CC'd the submitter (not the project manager).");

                foreach (var adminId in GetPrimaryAdminIds(service, tracing))
                {
                    if (adminId == Guid.Empty) continue;
                    // An admin can be the PM on their own request - don't list them twice.
                    if (PartyListHas(toParties, adminId) || PartyListHas(ccParties, adminId)) continue;
                    var cc = new Entity("activityparty");
                    cc["partyid"] = new EntityReference("systemuser", adminId);
                    ccParties.Add(cc);
                }
                if (ccParties.Count > 0)
                {
                    email["cc"] = new EntityCollection(ccParties) { EntityName = "activityparty" };
                    tracing.Trace("LogSetupCompleteEmail: {0} CC recipient(s).", ccParties.Count);
                }

                Guid emailId = service.Create(email);
                var setState = new OrganizationRequest("SetState");
                setState["EntityMoniker"] = new EntityReference("email", emailId);
                setState["State"] = new OptionSetValue(1);
                setState["Status"] = new OptionSetValue(3);
                service.Execute(setState);
                tracing.Trace("Setup-complete email logged for request {0}.", requestId);
            }
            catch (Exception ex)
            {
                tracing.Trace("LogSetupCompleteEmail failed (non-fatal): {0}", ex.Message);
            }
        }

        // DEF-005: emails the PM/requester that their request was cancelled, with the reason.
        // Mirrors the Changes-Requested template. Non-fatal - a failed notification must never
        // block the cancellation itself.
        private static void LogCancelEmail(IOrganizationService service, ITracingService tracing,
            Entity req, Guid requestId, string title, string identifier,
            string cancelledBy, string reason, Guid pmId, Guid cancelledById, string orgBaseUrl, string linkUrl)
        {
            try
            {
                string location = CardFormatted(req, FieldLocation);
                string projectType = CardFormatted(req, FieldProjectType);
                string deepLink = string.IsNullOrEmpty(orgBaseUrl) ? (linkUrl ?? "")
                    : (orgBaseUrl + "/main.aspx?pagetype=entityrecord&etn=" + EntityRequest + "&id=" + requestId);

                var email = new Entity("email");
                email["subject"] = "PAMS Project Approval Request - " + title + " - Cancelled";
                email["description"] = BuildCancelCardHtml(service, tracing, title, identifier, location, projectType,
                                                           cancelledBy, reason, deepLink);
                email["directioncode"] = true;
                email["regardingobjectid"] = new EntityReference(EntityRequest, requestId);

                // From = whoever cancelled it, so the email record shows who the action came from
                // rather than being blank.
                if (cancelledById != Guid.Empty)
                {
                    var from = new Entity("activityparty");
                    from["partyid"] = new EntityReference("systemuser", cancelledById);
                    email["from"] = new EntityCollection(new List<Entity> { from }) { EntityName = "activityparty" };
                }

                var to = new Entity("activityparty");
                to["partyid"] = new EntityReference("systemuser", pmId);
                var toParties = new List<Entity> { to };
                email["to"] = new EntityCollection(toParties) { EntityName = "activityparty" };

                // CC the submitter when they are not the PM - a cancelled request is terminal in
                // this build, so without this they would never learn it had been stopped.
                var ccParties = new List<Entity>();
                if (AddCcIfNew(toParties, ccParties, RequesterId(req)))
                    tracing.Trace("LogCancelEmail: CC'd the submitter (not the project manager).");
                if (ccParties.Count > 0)
                    email["cc"] = new EntityCollection(ccParties) { EntityName = "activityparty" };

                Guid emailId = service.Create(email);
                var setState = new OrganizationRequest("SetState");
                setState["EntityMoniker"] = new EntityReference("email", emailId);
                setState["State"] = new OptionSetValue(1);
                setState["Status"] = new OptionSetValue(3);
                service.Execute(setState);
                tracing.Trace("Cancellation email logged for request {0} (from {1}).", requestId, cancelledById);
            }
            catch (Exception ex)
            {
                tracing.Trace("LogCancelEmail failed (non-fatal): {0}", ex.Message);
            }
        }

        private static string BuildCancelCardHtml(IOrganizationService service, ITracingService tracing, string title, string identifier, string location,
            string projectType, string cancelledBy, string reason, string deepLink)
        {
            string logo = LogoFromDeepLink(service, tracing, deepLink);
            string facts = HtmlFactRow("Project ID:", identifier)
                         + HtmlFactRow("Location:", location)
                         + HtmlFactRow("Project Type:", projectType)
                         + HtmlFactRow("Cancelled by:", cancelledBy);
            string extra = BrandedQuote("Reason", reason, "#a4262c");
            string intro = "This request has been cancelled and is no longer in the approval process. No further action is needed.";
            return BrandedShell(null, logo, title, "This request was cancelled", "#a4262c",
                                intro, facts, extra, deepLink);
        }

        // Power Automate flow that sends approval emails also sends this one. Non-fatal on error.
        private static void LogReturnEmail(IOrganizationService service, ITracingService tracing,
            Entity req, Guid requestId, string title, string identifier, string role,
            string comment, Guid approverId, string orgBaseUrl, string linkUrl, bool isReject)
        {
            try
            {
                // Prefer the current Project Manager (defaults to the creator but can be
                // reassigned); fall back to the creator.
                var pmRef = req.GetAttributeValue<EntityReference>(FieldProjectManager)
                            ?? req.GetAttributeValue<EntityReference>(FieldCreatedBy);
                if (pmRef == null || pmRef.Id == Guid.Empty)
                {
                    tracing.Trace("LogReturnEmail: no PM/creator; skipping.");
                    return;
                }

                string location = "";
                var locRef = req.GetAttributeValue<EntityReference>(FieldLocation);
                if (locRef != null) location = locRef.Name ?? "";
                string projectType = CardFormatted(req, FieldProjectType);
                string deepLink = string.IsNullOrEmpty(orgBaseUrl) ? (linkUrl ?? "")
                    : (orgBaseUrl + "/main.aspx?pagetype=entityrecord&etn=" + EntityRequest + "&id=" + requestId);

                string cardHtml = BuildReturnCardHtml(service, tracing, title, identifier, location, projectType, role, comment, deepLink, isReject);

                var email = new Entity("email");
                // Shared PAMS subject prefix so the existing notification flow picks it up.
                email["subject"] = "PAMS Project Approval Request - " + title + (isReject ? " - Rejected" : " - Changes Requested");
                email["description"] = cardHtml;
                email["directioncode"] = true; // Outgoing
                email["regardingobjectid"] = new EntityReference(EntityRequest, requestId);

                // From = the approver who acted; To = the PM (creator).
                if (approverId != Guid.Empty)
                {
                    var from = new Entity("activityparty");
                    from["partyid"] = new EntityReference("systemuser", approverId);
                    email["from"] = new EntityCollection(new List<Entity> { from }) { EntityName = "activityparty" };
                }
                var to = new Entity("activityparty");
                to["partyid"] = new EntityReference("systemuser", pmRef.Id);
                var toParties = new List<Entity> { to };
                email["to"] = new EntityCollection(toParties) { EntityName = "activityparty" };

                // CC the SUBMITTER when they are not the PM. A rejection or a return for changes
                // is the one outcome the person who raised the request most needs to see, and the
                // To line above resolves to the PM - so with a reassigned PM they heard nothing.
                var ccParties = new List<Entity>();
                if (AddCcIfNew(toParties, ccParties, RequesterId(req)))
                    tracing.Trace("LogReturnEmail: CC'd the submitter (not the project manager).");
                if (ccParties.Count > 0)
                    email["cc"] = new EntityCollection(ccParties) { EntityName = "activityparty" };

                Guid emailId = service.Create(email);

                var setState = new OrganizationRequest("SetState");
                setState["EntityMoniker"] = new EntityReference("email", emailId);
                setState["State"] = new OptionSetValue(1); // Completed
                setState["Status"] = new OptionSetValue(3); // Sent
                service.Execute(setState);
            }
            catch (Exception ex)
            {
                tracing.Trace("LogReturnEmail failed (non-fatal): {0}", ex.Message);
            }
        }

        // Builds the return notification (Changes Requested OR Rejected): Adaptive Card
        // (FactSet + comment + Open in PAMS) wrapped in an HTML shell with a plain-HTML fallback.
        private static string BuildReturnCardHtml(IOrganizationService service, ITracingService tracing, string title, string identifier, string location,
            string projectType, string role, string comment, string deepLink, bool isReject)
        {
            string headerText = isReject ? "Your PAMS request was rejected" : "Changes requested on a PAMS request";
            string subText = isReject
                ? "This request was rejected. See the reason below."
                : "Your request needs changes before it can proceed.";
            string commentHeading = isReject ? "Reason for rejection" : "Requested changes";
            string bodyLead = isReject ? "was rejected" : "needs changes";

            var card = new StringBuilder();
            card.Append("{\"type\":\"AdaptiveCard\",\"$schema\":\"http://adaptivecards.io/schemas/adaptive-card.json\",\"version\":\"1.6\",");
            card.Append("\"body\":[");
            string rLogo = LogoFromDeepLink(service, tracing, deepLink);
            if (!string.IsNullOrEmpty(rLogo))
                card.Append("{\"type\":\"Image\",\"url\":").Append(J(rLogo)).Append(",\"horizontalAlignment\":\"Center\",\"width\":\"190px\",\"spacing\":\"None\",\"altText\":\"Morton Salt\"},");
            card.Append("{\"type\":\"TextBlock\",\"size\":\"Medium\",\"weight\":\"Bolder\",\"text\":").Append(J(headerText)).Append("},");
            card.Append("{\"type\":\"TextBlock\",\"size\":\"Large\",\"weight\":\"Bolder\",\"spacing\":\"None\",\"wrap\":true,\"text\":").Append(J(title)).Append("},");
            card.Append("{\"type\":\"TextBlock\",\"weight\":\"Bolder\",\"color\":\"").Append(isReject ? "Attention" : "Warning").Append("\",\"wrap\":true,\"text\":").Append(J(subText)).Append("},");
            card.Append("{\"type\":\"FactSet\",\"separator\":true,\"spacing\":\"Medium\",\"facts\":[");
            card.Append("{\"title\":\"Project Title:\",\"value\":").Append(J(title)).Append("},");
            card.Append("{\"title\":\"Project ID:\",\"value\":").Append(J(identifier)).Append("},");
            card.Append("{\"title\":\"Location:\",\"value\":").Append(J(location)).Append("},");
            card.Append("{\"title\":\"Project Type:\",\"value\":").Append(J(projectType)).Append("},");
            card.Append("{\"title\":\"").Append(isReject ? "Rejected by:" : "Returned by:").Append("\",\"value\":").Append(J(string.IsNullOrEmpty(role) ? "Approver" : role)).Append("}");
            card.Append("]},");
            card.Append("{\"type\":\"TextBlock\",\"weight\":\"Bolder\",\"separator\":true,\"spacing\":\"Medium\",\"text\":").Append(J(commentHeading)).Append("},");
            card.Append("{\"type\":\"TextBlock\",\"wrap\":true,\"spacing\":\"None\",\"text\":").Append(J(comment ?? "")).Append("}");
            card.Append("]");
            if (!string.IsNullOrEmpty(deepLink))
            {
                card.Append(",\"actions\":[{\"type\":\"Action.OpenUrl\",\"title\":\"Open in PAMS\",\"url\":").Append(J(deepLink)).Append("}]");
            }
            card.Append("}");

            string facts = HtmlFactRow("Project ID:", identifier)
                         + HtmlFactRow("Location:", location)
                         + HtmlFactRow("Project Type:", projectType)
                         + HtmlFactRow(isReject ? "Rejected by:" : "Returned by:", string.IsNullOrEmpty(role) ? "Approver" : role);
            string extra = BrandedQuote(commentHeading, comment, isReject ? "#a4262c" : "#0f6cbd");
            return BrandedShell(card.ToString(), rLogo, title,
                                isReject ? "This request was rejected" : "Changes were requested",
                                isReject ? "#a4262c" : "#ca5010",
                                "Your PAMS request " + bodyLead + ".", facts, extra, deepLink);
        }

        private static string HtmlFactRow(string label, string value)
        {
            return "<tr><td style=\"padding:2px 12px 2px 0;color:#666;\">"
                 + System.Security.SecurityElement.Escape(label ?? "")
                 + "</td><td style=\"padding:2px 0;\">"
                 + System.Security.SecurityElement.Escape(value ?? "")
                 + "</td></tr>";
        }

        // Logs a Dataverse email activity row for the approval notification sent to the current
        // approver. From = request creator (systemuser), To = current approver (systemuser).
        // Standalone (no regarding). Created then stamped Sent (state Completed / status Sent).
        // Failures are non-fatal - logging the notification must never block the decision flow.
        private static void LogApprovalEmail(IOrganizationService service, ITracingService tracing,
            Entity req, Guid requestId, string title, string identifier, int step, string role,
            Guid? toApproverId, string cardHtml, Guid? ccUserId = null)
        {
            try
            {
                var creatorRef = req.GetAttributeValue<EntityReference>(FieldCreatedBy);
                if (!toApproverId.HasValue || toApproverId.Value == Guid.Empty)
                {
                    tracing.Trace("LogApprovalEmail: no approver id; skipping email log.");
                    return;
                }

                var email = new Entity("email");
                email["subject"] = "PAMS Project Approval Request - " + title + " - Step " + step + (string.IsNullOrEmpty(role) ? "" : " - " + role);
                // Description carries the Adaptive Card HTML (same structure as comment emails) so a
                // single Power Automate flow can send ALL PAMS notifications from email.description.
                email["description"] = !string.IsNullOrEmpty(cardHtml)
                    ? cardHtml
                    : ("Approval notification for " + title + ". Step " + step
                       + (string.IsNullOrEmpty(role) ? "" : " - " + role) + ".");
                email["directioncode"] = true; // Outgoing
                // Regarding the request, so it shows in the request's Activities/Email subgrid.
                email["regardingobjectid"] = new EntityReference(EntityRequest, requestId);

                // From = creator, To = approver. Set via the email's dedicated 'from'/'to'
                // party-list attributes (NOT a generic collection). Each is an EntityCollection
                // of activityparty; the attribute itself implies the participation type, so we
                // do NOT set participationtypemask manually.
                if (creatorRef != null)
                {
                    var from = new Entity("activityparty");
                    from["partyid"] = new EntityReference("systemuser", creatorRef.Id);
                    email["from"] = new EntityCollection(new List<Entity> { from }) { EntityName = "activityparty" };
                }
                var to = new Entity("activityparty");
                to["partyid"] = new EntityReference("systemuser", toApproverId.Value);
                email["to"] = new EntityCollection(new List<Entity> { to }) { EntityName = "activityparty" };

                // Optional CC - used on reassignment so the OUTGOING approver knows the step moved
                // off them (DEF-004). Skipped when it would just CC the same person.
                if (ccUserId.HasValue && ccUserId.Value != Guid.Empty && ccUserId.Value != toApproverId.Value)
                {
                    var cc = new Entity("activityparty");
                    cc["partyid"] = new EntityReference("systemuser", ccUserId.Value);
                    email["cc"] = new EntityCollection(new List<Entity> { cc }) { EntityName = "activityparty" };
                }

                Guid emailId = service.Create(email);

                // Stamp as Sent: state Completed (1) / status Sent (3). Can't be set on Create.
                var setState = new OrganizationRequest("SetState");
                setState["EntityMoniker"] = new EntityReference("email", emailId);
                setState["State"] = new OptionSetValue(1); // Completed
                setState["Status"] = new OptionSetValue(3); // Sent
                service.Execute(setState);
            }
            catch (Exception ex)
            {
                tracing.Trace("LogApprovalEmail failed (non-fatal): {0}", ex.Message);
            }
        }

        // Reads an environment variable's value by schema name. Returns "" if not configured.
        // The current value (per environment) overrides the definition's default value. Any
        // trailing slash is trimmed (safe for URLs; harmless otherwise).
        // Resolves the model-driven app id from the appmodule table by its stable unique name.
        // Portable across environments (the id differs per environment, the unique name doesn't).
        // Non-fatal: if the app can't be found, returns "" and links simply omit &appid=.
        private static string ResolveAppId(IOrganizationService service, ITracingService tracing)
        {
            try
            {
                var q = new QueryExpression("appmodule")
                {
                    ColumnSet = new ColumnSet("appmoduleid"),
                    TopCount = 1,
                    Criteria = new FilterExpression(LogicalOperator.And)
                };
                q.Criteria.AddCondition("uniquename", ConditionOperator.Equal, AppUniqueName);
                var res = service.RetrieveMultiple(q);
                if (res.Entities.Count > 0)
                    return res.Entities[0].GetAttributeValue<Guid>("appmoduleid").ToString();
                tracing.Trace("ResolveAppId: no appmodule with uniquename '{0}'.", AppUniqueName);
            }
            catch (Exception ex)
            {
                tracing.Trace("ResolveAppId failed (non-fatal): {0}", ex.Message);
            }
            return "";
        }

        private static string GetEnvVar(IOrganizationService service, ITracingService tracing, string schemaName)
        {
            try
            {
                var q = new QueryExpression("environmentvariabledefinition")
                {
                    ColumnSet = new ColumnSet("environmentvariabledefinitionid", "defaultvalue", "schemaname"),
                    Criteria = new FilterExpression()
                };
                q.Criteria.AddCondition("schemaname", ConditionOperator.Equal, schemaName);

                // Left-outer join to the value table so we get the current value if present.
                var link = q.AddLink("environmentvariablevalue", "environmentvariabledefinitionid",
                                     "environmentvariabledefinitionid", JoinOperator.LeftOuter);
                link.EntityAlias = "val";
                link.Columns = new ColumnSet("value");

                var res = service.RetrieveMultiple(q).Entities.FirstOrDefault();
                if (res == null) { tracing.Trace("Env var {0} not found.", schemaName); return ""; }

                string current = null;
                if (res.Contains("val.value") && res["val.value"] is AliasedValue av && av.Value is string s)
                    current = s;
                string def = res.GetAttributeValue<string>("defaultvalue");

                string val = !string.IsNullOrWhiteSpace(current) ? current : def;
                if (string.IsNullOrWhiteSpace(val)) return "";
                return val.TrimEnd('/');
            }
            catch (Exception ex)
            {
                tracing.Trace("GetEnvVar({0}) failed (non-fatal): {1}", schemaName, ex.Message);
                return "";
            }
        }

        // Ensure a user is a (non-manual) watcher of the request (req 33.3.2.4.1). Creating the
        // watcher row also re-shares the request via the RequestWatcher sharing plugin. Non-fatal.
        private void EnsureWatcher(IOrganizationService service, ITracingService tracing,
                                   Guid requestId, Guid userId, Guid addedBy)
        {
            try
            {
                var q = new QueryExpression(EntityWatcher)
                {
                    ColumnSet = new ColumnSet("pams_requestwatcherid"),
                    Criteria = new FilterExpression(LogicalOperator.And)
                };
                q.Criteria.AddCondition("pams_requestid", ConditionOperator.Equal, requestId);
                q.Criteria.AddCondition("pams_watcherid", ConditionOperator.Equal, userId);
                if (service.RetrieveMultiple(q).Entities.Count > 0) return; // already a watcher

                service.Create(new Entity(EntityWatcher)
                {
                    ["pams_requestid"] = new EntityReference(EntityRequest, requestId),
                    ["pams_watcherid"] = new EntityReference("systemuser", userId),
                    ["pams_addedon"] = DateTime.UtcNow,
                    ["pams_ismanual"] = false,            // system-added: not removable (req 52)
                    ["pams_watchersource"] = new OptionSetValue(WatcherSourceApprover),
                    // Read on creation; the reassign path calls SetWatcherAccess immediately after
                    // and raises this to Write when the step they took over is the current one.
                    ["pams_accesslevel"] = new OptionSetValue(AccessLevelRead),
                    ["pams_addedbyid"] = new EntityReference("systemuser", addedBy)
                });
            }
            catch (Exception ex) { tracing.Trace("EnsureWatcher failed (non-fatal): {0}", ex.Message); }
        }

        // Write a note to the request's timeline (annotation), attributed to the acting user
        // via impersonation, so the timeline shows who actually did it. The record write is
        // still done by SYSTEM; only the note is impersonated. Never breaks the decision.
        private void PostNote(IOrganizationServiceFactory factory, ITracingService tracing,
                              Guid actorId, Guid requestId, string subject, string body)
        {
            try
            {
                var asActor = factory.CreateOrganizationService(actorId);
                asActor.Create(new Entity("annotation")
                {
                    ["objectid"] = new EntityReference(EntityRequest, requestId),
                    ["subject"] = subject,
                    ["notetext"] = body
                });
            }
            catch (Exception ex) { tracing.Trace("Timeline note failed: {0}", ex.Message); }
        }

        // Resolve a user's display name for the story.
        // "Trent Roehler (VP)". Falls back to whichever part is known; empty when neither is.
        private static string NameWithRole(string name, string role)
        {
            bool hasName = !string.IsNullOrWhiteSpace(name);
            bool hasRole = !string.IsNullOrWhiteSpace(role);
            if (hasName && hasRole) return name + " (" + role + ")";
            if (hasName) return name;
            if (hasRole) return "(" + role + ")";
            return "";
        }

        private string UserName(IOrganizationService service, Guid userId)
        {
            try { return service.Retrieve("systemuser", userId, new ColumnSet("fullname")).GetAttributeValue<string>("fullname"); }
            catch { return "A user"; }
        }

        private static T In<T>(IPluginExecutionContext c, string k)
        {
            if (c.InputParameters.Contains(k) && c.InputParameters[k] is T t) return t;
            return default;
        }
        private static void Out(IPluginExecutionContext c, int status, int step, string msg)
        {
            c.OutputParameters["NewStatus"] = status.ToString();
            c.OutputParameters["CurrentStep"] = step;
            c.OutputParameters["Message"] = msg;
        }

        private static List<ChainStep> Deserialize(string json)
        {
            using (var ms = new MemoryStream(Encoding.UTF8.GetBytes(json)))
            {
                if (json.TrimStart().StartsWith("{"))
                {
                    var w = (Wrapper)new DataContractJsonSerializer(typeof(Wrapper)).ReadObject(ms);
                    return w.Chain ?? new List<ChainStep>();
                }
                return (List<ChainStep>)new DataContractJsonSerializer(typeof(List<ChainStep>)).ReadObject(ms);
            }
        }
        private static string Serialize(List<ChainStep> chain)
        {
            using (var ms = new MemoryStream())
            {
                new DataContractJsonSerializer(typeof(List<ChainStep>)).WriteObject(ms, chain);
                return Encoding.UTF8.GetString(ms.ToArray());
            }
        }

        // EntityReference to the Approval Rule a chain step came from (for the request's Current
        // Approval Step lookup). Null when the step is null / has no rule id (setup step or legacy
        // chain) / the id can't be parsed - so the lookup is cleared appropriately.
        private static EntityReference RuleRefFromStep(ChainStep step)
        {
            if (step == null || string.IsNullOrWhiteSpace(step.RuleId)) return null;
            Guid g;
            if (!Guid.TryParse(step.RuleId.Replace("{", "").Replace("}", ""), out g)) return null;
            return new EntityReference(RuleEntity, g);
        }

        // ============================ approval card =============================
        //  Builds the fully-resolved Adaptive Card for the current approver and
        //  returns it as a string, to be stored on pams_adaptivecardjson in the
        //  same update. 'req' supplies display fields; 'chain'/'currentStep' must
        //  reflect POST-change state. 'orgBaseUrl' is the resolved deep-link base
        //  ("" omits the Open-in-PAMS action). 'actionUrl' is the HTTPS endpoint the
        //  Approve/Changes/Reject buttons POST to; when "" the buttons fall back to
        //  Action.Submit (flow-mediated / Teams only, not raw email). 'originator' is
        //  the Actionable Message provider GUID, emitted at the card root when set.
        private static string BuildCard(IOrganizationService service, ITracingService tracing, Entity req, Guid requestId, List<ChainStep> chain, int currentStep, string orgBaseUrl, string actionUrl, string originator, string linkUrl, string appId, DateTime? submitLocal)
        {
            string title = CardStr(req, FieldTitle);
            string identifier = CardStr(req, FieldIdentifier);
            string submittedBy = CardFormatted(req, FieldCreatedBy);
            // Resolved once in Execute, in the SUBMITTER's timezone (see ResolveSubmitLocal).
            string submitDate = CardDate(submitLocal);
            string projectType = CardFormatted(req, FieldProjectType);
            string location = CardFormatted(req, FieldLocation);
            decimal usd = req.GetAttributeValue<decimal?>(FieldUsdAmount)
                          ?? req.GetAttributeValue<decimal?>(FieldBaseAmount) ?? 0m;
            string totalDisp = CardUsd(usd);

            int total = chain.Count;
            string curRole = "", curApprover = "", curApproverId = "";
            foreach (var c in chain)
                if (c.Step == currentStep) { curRole = c.Role ?? ""; curApprover = c.Approver ?? ""; curApproverId = c.ApproverId ?? ""; break; }

            var sb = new StringBuilder(4096);
            sb.Append("{\"type\":\"AdaptiveCard\",\"$schema\":\"http://adaptivecards.io/schemas/adaptive-card.json\",\"version\":\"1.6\",");
            if (!string.IsNullOrEmpty(originator))
                sb.Append("\"originator\":").Append(J(originator)).Append(",");
            sb.Append("\"body\":[");

            string logo = ResolveLogo(service, tracing, orgBaseUrl);
            if (!string.IsNullOrEmpty(logo))
                sb.Append("{\"type\":\"Image\",\"url\":").Append(J(logo))
                  .Append(",\"horizontalAlignment\":\"Center\",\"width\":\"190px\",\"spacing\":\"None\",\"altText\":\"Morton Salt\"},");

            sb.Append("{\"type\":\"TextBlock\",\"size\":\"Medium\",\"weight\":\"Bolder\",\"text\":\"PAMS Project Approval Request\"},");
            sb.Append("{\"type\":\"TextBlock\",\"size\":\"Large\",\"weight\":\"Bolder\",\"spacing\":\"None\",\"wrap\":true,\"text\":")
              .Append(J(title)).Append("},");

            sb.Append("{\"type\":\"ColumnSet\",\"columns\":[{\"type\":\"Column\",\"width\":\"stretch\",\"items\":[");
            sb.Append("{\"type\":\"TextBlock\",\"weight\":\"Bolder\",\"color\":\"Warning\",\"wrap\":true,\"text\":\"Awaiting your approval\"},");
            sb.Append("{\"type\":\"TextBlock\",\"spacing\":\"None\",\"isSubtle\":true,\"wrap\":true,\"text\":")
              .Append(J(curRole + " - Step " + currentStep + " of " + total)).Append("}");
            sb.Append("]}]},");

            sb.Append("{\"type\":\"TextBlock\",\"isSubtle\":true,\"wrap\":true,\"text\":")
              .Append(J("Submitted by " + submittedBy + " on " + submitDate)).Append("},");

            sb.Append("{\"type\":\"FactSet\",\"facts\":[");
            CardFact(sb, "Project ID:", identifier, true);
            CardFact(sb, "Location:", location, false);
            CardFact(sb, "Project Type:", projectType, false);
            CardFact(sb, "Total to be Authorized:", totalDisp, false);
            sb.Append("]},");

            sb.Append("{\"type\":\"TextBlock\",\"text\":\"Approval Progress\",\"weight\":\"Bolder\",\"separator\":true,\"spacing\":\"Medium\",\"wrap\":true},");
            sb.Append("{\"type\":\"FactSet\",\"facts\":[").Append(CardChainFacts(chain)).Append("]},");

            // A note the submitter wrote for THIS approver (submit modal), shown above the
            // attachments line. Outlook renders the adaptive card, so this is the one that matters.
            string subNoteCard = "";
            foreach (var c in chain) if (c.Step == currentStep) { subNoteCard = c.SubmitterNote ?? ""; break; }
            if (!string.IsNullOrWhiteSpace(subNoteCard))
            {
                sb.Append("{\"type\":\"TextBlock\",\"weight\":\"Bolder\",\"spacing\":\"Medium\",\"wrap\":true,\"text\":")
                  .Append(J("Note from " + submittedBy)).Append("},");
                sb.Append("{\"type\":\"TextBlock\",\"wrap\":true,\"spacing\":\"Small\",\"text\":")
                  .Append(J(subNoteCard)).Append("},");
            }
            sb.Append("{\"type\":\"TextBlock\",\"size\":\"Small\",\"isSubtle\":true,\"spacing\":\"Medium\",\"wrap\":true,\"text\":\"").Append(DocumentsNotice).Append("\"}");
            // Decision buttons ALWAYS go through the authenticated action page (DEF-029). We no
            // longer render an inline Action.Http button (that path asserted identity via ApproverId
            // in the POST body with no sign-in). If orgBaseUrl isn't configured we render no decision
            // buttons at all - the "Open in PAMS" deep link below lets the approver act in-app. The
            // action page collects the comment itself, so no inline comment field is needed.
            sb.Append("],");

            sb.Append("\"actions\":[");
            if (!string.IsNullOrEmpty(orgBaseUrl))
            {
                CardLinkAction(sb, "Approve", orgBaseUrl, appId, requestId, "Approve", true, currentStep);
                sb.Append(",");
                CardLinkAction(sb, "Request Changes", orgBaseUrl, appId, requestId, "RequestChanges", false, currentStep);
                sb.Append(",");
                CardLinkAction(sb, "Reject", orgBaseUrl, appId, requestId, "Reject", false, currentStep);
                // "Open in PAMS" opens the RECORD (not the action page) - handy for reviewing detail.
                string recUrl = orgBaseUrl.TrimEnd('/') + "/main.aspx?";
                if (!string.IsNullOrEmpty(appId)) recUrl += "appid=" + Uri.EscapeDataString(appId) + "&";
                recUrl += "pagetype=entityrecord&etn=" + EntityRequest + "&id=" + requestId;
                sb.Append(",{\"type\":\"Action.OpenUrl\",\"title\":\"Open in PAMS\",\"url\":").Append(J(recUrl)).Append("}");
            }
            sb.Append("]}");

            return sb.ToString();
        }

        // Builds an Action.OpenUrl decision LINK. The URL is the flow trigger with the decision
        // and ids in the query string. Always renders in Outlook (no actionable-message needed).
        // The '&' separator assumes linkUrl already has a query string (e.g. ...?api-version=1&sig=).
        // If linkUrl has no '?', switch the first separator to '?'.
        // Builds an Action.OpenUrl decision LINK pointing at the AUTHENTICATED action page (web
        // resource in the app), NOT the old flow trigger. Only requestId + decision travel in the
        // URL; identity is established by sign-in when the page opens (DEF-029).
        private static void CardLinkAction(StringBuilder sb, string title, string orgBaseUrl, string appId,
            Guid requestId, string decision, bool positive, int step)
        {
            string url = BuildActionUrl(orgBaseUrl, appId, requestId, decision, step);
            if (string.IsNullOrEmpty(url)) return;
            sb.Append("{\"type\":\"Action.OpenUrl\",\"title\":").Append(J(title))
              .Append(",\"url\":").Append(J(url));
            if (positive) sb.Append(",\"style\":\"positive\"");
            sb.Append("}");
        }

        private static string CardChainFacts(List<ChainStep> chain)
        {
            var sb = new StringBuilder();
            for (int i = 0; i < chain.Count; i++)
            {
                var c = chain[i];
                string val = c.Approver ?? "";
                if (!string.IsNullOrEmpty(c.StatusLabel)) val += " - " + c.StatusLabel;
                CardFact(sb, c.Step + ". " + (c.Role ?? ""), val, i == 0);
            }
            return sb.ToString();
        }

        // (CardHttpAction removed for DEF-029: the inline Action.Http button POSTed decisions to an
        // unauthenticated endpoint with the approver identity asserted in the body. All decisions now
        // route through the authenticated action page via CardLinkAction.)

        // Escapes a string for embedding inside the already-escaped Action.Http body literal.
        private static string JEsc(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("\\", "\\\\").Replace("\"", "\\\"");
        }

        private static void CardFact(StringBuilder sb, string title, string value, bool first)
        {
            if (!first) sb.Append(",");
            sb.Append("{\"title\":").Append(J(title)).Append(",\"value\":").Append(J(value)).Append("}");
        }

        private static string CardStr(Entity e, string f) => e.Contains(f) && e[f] != null ? e[f].ToString() : "";
        private static DateTime? CardDateVal(Entity e, string f) => e.Contains(f) && e[f] is DateTime dt ? dt : (DateTime?)null;
        private static string CardFormatted(Entity e, string f)
            => e.FormattedValues != null && e.FormattedValues.Contains(f) ? e.FormattedValues[f] : "";
        private static string CardUsd(decimal v) => "$" + v.ToString("#,##0.00", CultureInfo.InvariantCulture);
        // ---- submission timestamp -> submitter's local date -------------------
        // "Submitted by X on <date>" is a statement about when X submitted, so it must render in
        // the SUBMITTER's timezone. CardDate alone formats the raw UTC instant, which rolls a
        // Pacific 5pm / Eastern 8pm submission onto the NEXT calendar day on every approval email.
        // NOTE: this is for real timestamps (pams_submissiondate). Do NOT apply it to
        // pams_projectstartdate - that is a Date-Only column and must not be timezone-converted.
        private static DateTime? ToUserLocal(IOrganizationService svc, ITracingService tracing, DateTime? utc, Guid userId)
        {
            if (!utc.HasValue) return null;
            if (svc == null || userId == Guid.Empty) return utc;
            try
            {
                var q = new QueryExpression("usersettings")
                {
                    ColumnSet = new ColumnSet("timezonecode"),
                    TopCount = 1,
                    Criteria = new FilterExpression()
                };
                q.Criteria.AddCondition("systemuserid", ConditionOperator.Equal, userId);
                var res = svc.RetrieveMultiple(q);
                if (res == null || res.Entities.Count == 0) return utc;
                int? tz = res.Entities[0].GetAttributeValue<int?>("timezonecode");
                if (!tz.HasValue) return utc;
                var conv = (LocalTimeFromUtcTimeResponse)svc.Execute(new LocalTimeFromUtcTimeRequest
                {
                    TimeZoneCode = tz.Value,
                    UtcTime = DateTime.SpecifyKind(utc.Value, DateTimeKind.Utc)
                });
                return conv.LocalTime;
            }
            catch (Exception ex)
            {
                // Never fail an approval email over a timezone lookup - fall back to UTC.
                if (tracing != null) tracing.Trace("Timezone convert failed, using UTC: {0}", ex.Message);
                return utc;
            }
        }

        // Resolve the submission timestamp ONCE per execution, in the submitter's timezone, so the
        // card builders don't each repeat the lookup.
        private static DateTime? ResolveSubmitLocal(IOrganizationService svc, ITracingService tracing, Entity req, string primaryDtField, string fallbackDtField, string createdByField)
        {
            DateTime? utc = CardDateVal(req, primaryDtField);
            if (utc == null && !string.IsNullOrEmpty(fallbackDtField)) utc = CardDateVal(req, fallbackDtField);
            if (utc == null) return null;
            Guid uid = Guid.Empty;
            var er = req.Contains(createdByField) ? req[createdByField] as EntityReference : null;
            if (er != null) uid = er.Id;
            return ToUserLocal(svc, tracing, utc, uid);
        }

        private static string CardDate(DateTime? d) => d.HasValue ? d.Value.ToString("M/d/yyyy", CultureInfo.InvariantCulture) : "";

        private static string J(string s)
        {
            if (s == null) return "\"\"";
            var sb = new StringBuilder(s.Length + 2);
            sb.Append('"');
            foreach (char c in s)
            {
                switch (c)
                {
                    case '"': sb.Append("\\\""); break;
                    case '\\': sb.Append("\\\\"); break;
                    case '\b': sb.Append("\\b"); break;
                    case '\f': sb.Append("\\f"); break;
                    case '\n': sb.Append("\\n"); break;
                    case '\r': sb.Append("\\r"); break;
                    case '\t': sb.Append("\\t"); break;
                    default:
                        if (c < ' ') sb.Append("\\u").Append(((int)c).ToString("x4"));
                        else sb.Append(c);
                        break;
                }
            }
            sb.Append('"');
            return sb.ToString();
        }

        [DataContract] private class Wrapper { [DataMember(Name = "chain")] public List<ChainStep> Chain { get; set; } }

        [DataContract]
        private class ChainStep
        {
            // IMPORTANT: this contract MUST stay identical to the ChainStep in
            // ApprovalChainBuilderPlugin. Both plugins deserialize and re-serialize the SAME
            // pams_approvalchainjson, and DataContractJsonSerializer silently DROPS any property
            // it doesn't know about. If one class is missing a field the other writes, that field
            // is destroyed the next time this plugin touches the chain.
            [DataMember(Name = "step", Order = 0)] public int Step { get; set; }
            [DataMember(Name = "role", Order = 1)] public string Role { get; set; }
            [DataMember(Name = "approver", Order = 2)] public string Approver { get; set; }
            [DataMember(Name = "approverId", Order = 3)] public string ApproverId { get; set; }
            [DataMember(Name = "statusLabel", Order = 4)] public string StatusLabel { get; set; }
            [DataMember(Name = "otherValidApproverIds", Order = 5, EmitDefaultValue = false)] public List<string> OtherValidApproverIds { get; set; }
            [DataMember(Name = "otherValidApproverNames", Order = 6, EmitDefaultValue = false)] public List<string> OtherValidApproverNames { get; set; }
            [DataMember(Name = "decisionComment", Order = 7, EmitDefaultValue = false)] public string DecisionComment { get; set; }
            [DataMember(Name = "decisionDate", Order = 8, EmitDefaultValue = false)] public string DecisionDate { get; set; }
            // Who ACTUALLY made the decision, when that is not the named approver - i.e. an
            // admin acting on behalf (req 33.1). Null on a normal decision, so the chain is
            // unchanged for every ordinary approval. Rendering it stops the stepper and the
            // emails implying the approver acted when somebody else did on their behalf.
            [DataMember(Name = "decidedBy", Order = 12, EmitDefaultValue = false)] public string DecidedBy { get; set; }
            [DataMember(Name = "submitterNote", Order = 9, EmitDefaultValue = false)] public string SubmitterNote { get; set; }
            // Marks the terminal Project Setup step (Option 1): a real chain step shown in the stepper
            // whose action is Complete Setup rather than Approve/Reject. MUST match the builder's
            // ChainStep exactly. EmitDefaultValue=false so pre-existing chains deserialize unchanged.
            [DataMember(Name = "isSetup", Order = 10, EmitDefaultValue = false)] public bool IsSetup { get; set; }
            // The Approval Rule record this step was generated from (pams_approvalrules id). Lets the
            // request's Current Approval Step lookup point at the governing rule. MUST match the
            // builder's ChainStep exactly. Empty for the setup step and legacy chains.
            [DataMember(Name = "ruleId", Order = 11, EmitDefaultValue = false)] public string RuleId { get; set; }
        }
    }

    // Shared snapshot of a request's editable "details" as of a return (Changes Requested / Rejected).
    // Written by the decision plugin on return; read by the chain builder on resubmit to (a) block a
    // no-change resubmit and (b) list what the PM changed. Keep this class IDENTICAL in both plugins.
    internal static class PamsSnapshot
    {
        // Column -> friendly label. Order controls how diffs are listed. FY columns included.
        internal static readonly Tuple<string, string>[] Fields = new[]
        {
            Tuple.Create("pams_projecttitle", "Project Title"),
            Tuple.Create("pams_projecttypeid", "Project Type"),
            Tuple.Create("pams_locationid", "Location"),
            Tuple.Create("pams_locationtypeid", "Location Type"),
            Tuple.Create("pams_projectstartdate", "Project Start Date"),
            Tuple.Create("pams_budgetedtotal", "Budgeted Total"),
            Tuple.Create("pams_totalauthorized", "Total to be Authorized"),
            Tuple.Create("pams_transactioncurrencyid", "Currency"),
            Tuple.Create("pams_budgetstatus", "Budget Status"),
            Tuple.Create("pams_assetclassid", "Asset Class"),
            Tuple.Create("pams_sensitive", "Sensitive"),
            Tuple.Create("pams_supplemental", "Supplemental"),
            Tuple.Create("pams_originalprojectrequest", "Original Project Request"),
            Tuple.Create("pams_costcentertext", "Cost Center"),
            Tuple.Create("pams_comments", "Comments"),
            Tuple.Create("pams_fy1year", "FY1 Year"), Tuple.Create("pams_fy1amount", "FY1 Amount"),
            Tuple.Create("pams_fy2year", "FY2 Year"), Tuple.Create("pams_fy2amount", "FY2 Amount"),
            Tuple.Create("pams_fy3year", "FY3 Year"), Tuple.Create("pams_fy3amount", "FY3 Amount"),
            Tuple.Create("pams_fy4year", "FY4 Year"), Tuple.Create("pams_fy4amount", "FY4 Amount")
        };

        // Reads the current values of the snapshot columns into a name->string map (JSON-serializable).
        // Uses ColumnSet(true) so a not-yet-created column can never make the Retrieve throw.
        internal static Dictionary<string, string> Capture(IOrganizationService service, string entity, Guid id)
        {
            var e = service.Retrieve(entity, id, new ColumnSet(true));
            var map = new Dictionary<string, string>();
            foreach (var f in Fields) map[f.Item1] = ValueString(e, f.Item1);
            return map;
        }

        // Normalizes an attribute to a stable comparable string (and human-readable where possible).
        internal static string ValueString(Entity e, string attr)
        {
            if (!e.Contains(attr) || e[attr] == null) return "";
            object v = e[attr];
            // Lookups: show the display name, not the raw GUID. The timeline diff is read by
            // approvers, and "Location: 9cc2a5e5-... -> 78c2a5e5-..." tells them nothing.
            // FormattedValues carries the primary name on a Retrieve; er.Name covers the cases where
            // it doesn't; the id remains the last resort so a diff is never silently empty.
            // NOTE: this must stay byte-identical to the same method in the other plugin - one
            // writes the snapshot, the other compares against it, and any difference in how a value
            // is stringified makes every lookup look changed on every resubmit.
            var er = v as EntityReference;
            if (er != null)
            {
                if (e.FormattedValues != null && e.FormattedValues.Contains(attr)
                    && !string.IsNullOrWhiteSpace(e.FormattedValues[attr])) return e.FormattedValues[attr];
                if (!string.IsNullOrWhiteSpace(er.Name)) return er.Name;
                return er.Id.ToString();
            }
            var os = v as OptionSetValue; if (os != null)
            {
                // Prefer the formatted (label) value if present.
                if (e.FormattedValues != null && e.FormattedValues.Contains(attr)) return e.FormattedValues[attr];
                return os.Value.ToString();
            }
            if (v is bool) return (bool)v ? "Yes" : "No";
            if (v is DateTime) return ((DateTime)v).ToString("o");
            var money = v as Money; if (money != null) return FormatAmount(money.Value);
            if (v is decimal) return FormatAmount((decimal)v);
            if (v is double) return FormatAmount((decimal)(double)v);
            if (v is int) return ((int)v).ToString("#,##0", CultureInfo.InvariantCulture);
            return v.ToString();
        }

        // Formats a numeric amount with thousands separators, trimming trailing zeros
        // (e.g. 658532.0000000000 -> "658,532", 1234.50 -> "1,234.50"). No currency symbol -
        // currency identity is tracked separately by the pams_transactioncurrencyid field.
        private static string FormatAmount(decimal d)
        {
            decimal r = Math.Round(d, 2);
            return (r == Math.Truncate(r))
                ? r.ToString("#,##0", CultureInfo.InvariantCulture)
                : r.ToString("#,##0.##", CultureInfo.InvariantCulture);
        }

        // Serialize/deserialize the map as JSON (simple, dependency-free).
        internal static string Serialize(Dictionary<string, string> map)
        {
            var sb = new StringBuilder("{");
            bool first = true;
            foreach (var kv in map)
            {
                if (!first) sb.Append(",");
                first = false;
                sb.Append(JStr(kv.Key)).Append(":").Append(JStr(kv.Value ?? ""));
            }
            sb.Append("}");
            return sb.ToString();
        }
        internal static Dictionary<string, string> Deserialize(string json)
        {
            var map = new Dictionary<string, string>();
            if (string.IsNullOrWhiteSpace(json)) return map;
            try
            {
                using (var ms = new System.IO.MemoryStream(System.Text.Encoding.UTF8.GetBytes(json)))
                {
                    var ser = new System.Runtime.Serialization.Json.DataContractJsonSerializer(typeof(Dictionary<string, string>),
                        new System.Runtime.Serialization.Json.DataContractJsonSerializerSettings { UseSimpleDictionaryFormat = true });
                    var obj = ser.ReadObject(ms) as Dictionary<string, string>;
                    if (obj != null) map = obj;
                }
            }
            catch { /* unparseable -> empty (treated as "no snapshot") */ }
            return map;
        }

        // Compares a stored snapshot to the current values; returns friendly change lines (empty = none).
        internal static List<string> Diff(Dictionary<string, string> was, Dictionary<string, string> now)
        {
            var changes = new List<string>();
            var labels = new Dictionary<string, string>();
            foreach (var f in Fields) labels[f.Item1] = f.Item2;
            foreach (var f in Fields)
            {
                string k = f.Item1;
                string w = was != null && was.ContainsKey(k) ? (was[k] ?? "") : "";
                string n = now != null && now.ContainsKey(k) ? (now[k] ?? "") : "";
                if (w != n)
                    changes.Add(labels[k] + ": \"" + (string.IsNullOrEmpty(w) ? "(empty)" : w) + "\" \u2192 \""
                        + (string.IsNullOrEmpty(n) ? "(empty)" : n) + "\"");
            }
            return changes;
        }

        private static string JStr(string s)
        {
            if (s == null) return "\"\"";
            var sb = new StringBuilder("\"");
            foreach (char c in s)
            {
                switch (c)
                {
                    case '"': sb.Append("\\\""); break;
                    case '\\': sb.Append("\\\\"); break;
                    case '\n': sb.Append("\\n"); break;
                    case '\r': sb.Append("\\r"); break;
                    case '\t': sb.Append("\\t"); break;
                    default: if (c < ' ') sb.Append("\\u").Append(((int)c).ToString("x4")); else sb.Append(c); break;
                }
            }
            sb.Append("\"");
            return sb.ToString();
        }
    }
}