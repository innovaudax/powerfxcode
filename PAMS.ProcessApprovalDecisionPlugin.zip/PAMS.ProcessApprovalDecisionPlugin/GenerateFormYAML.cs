﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Newtonsoft.Json.Linq;

namespace Innovaudax.Dataverse.Plugins
{
    public class GenerateFormYAML : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var formName = context.InputParameters.Contains("formName") ? context.InputParameters["formName"]?.ToString() : "PopupContainer";
            var fieldsJson = context.InputParameters.Contains("fields") ? context.InputParameters["fields"]?.ToString() : "[]";
            var fields = JArray.Parse(fieldsJson);

            string yaml = GenerateFormYaml(formName, fields);
            context.OutputParameters["yamltext"] = yaml;
        }

        private string GenerateFormYaml(string formName, JArray fields)
        {
            var sb = new StringBuilder();
            string indent1 = "  ";
            string indent2 = "    ";
            string indent3 = "      ";
            string indent4 = "        ";

            sb.AppendLine($"- vcnt_{formName}_1:");
            sb.AppendLine($"{indent1}Control: GroupContainer@1.3.0");
            sb.AppendLine($"{indent1}Variant: AutoLayout");
            sb.AppendLine($"{indent1}Properties:");
            sb.AppendLine($"{indent2}BorderColor: =RGBA(173, 173, 173, 1)");
            sb.AppendLine($"{indent2}BorderThickness: =1");
            sb.AppendLine($"{indent2}Fill: =RGBA(250, 250, 250, 1)");
            sb.AppendLine($"{indent2}Height: =Parent.Height * 0.85");
            sb.AppendLine($"{indent2}LayoutDirection: =LayoutDirection.Vertical");
            sb.AppendLine($"{indent2}LayoutGap: =12");
            sb.AppendLine($"{indent2}PaddingBottom: =16");
            sb.AppendLine($"{indent2}PaddingLeft: =16");
            sb.AppendLine($"{indent2}PaddingRight: =16");
            sb.AppendLine($"{indent2}PaddingTop: =16");
            sb.AppendLine($"{indent2}Width: =Parent.Width * 0.85");
            sb.AppendLine($"{indent2}X: =(Parent.Width - Self.Width) / 2");
            sb.AppendLine($"{indent2}Y: =(Parent.Height - Self.Height) / 2");
            sb.AppendLine($"{indent1}Children:");

            // Build fields dynamically
            int index = 1;
            foreach (var field in fields)
            {
                string name = field["name"]?.ToString() ?? $"Field{index}";
                string type = field["type"]?.ToString() ?? "Text";

                sb.AppendLine($"{indent2}- hcnt_FieldContainer{index}_1:");
                sb.AppendLine($"{indent3}Control: GroupContainer@1.3.0");
                sb.AppendLine($"{indent3}Variant: AutoLayout");
                sb.AppendLine($"{indent3}Properties:");
                sb.AppendLine($"{indent4}Height: =64");
                sb.AppendLine($"{indent4}LayoutDirection: =LayoutDirection.Vertical");
                sb.AppendLine($"{indent4}PaddingTop: =6");
                sb.AppendLine($"{indent4}PaddingBottom: =6");
                sb.AppendLine($"{indent3}Children:");
                sb.AppendLine($"{indent4}- txt_{name.Replace(" ", "")}_1:");
                sb.AppendLine($"{indent4}{indent1}Control: Text@0.0.51");
                sb.AppendLine($"{indent4}{indent1}Properties:");
                sb.AppendLine($"{indent4}{indent2}Text: =\"{name}\"");
                sb.AppendLine($"{indent4}{indent2}Weight: ='TextCanvas.Weight'.Semibold");

                // Add Input control depending on type
                sb.AppendLine($"{indent4}- input_{name.Replace(" ", "")}_1:");
                switch (type.ToLower())
                {
                    case "date":
                        sb.AppendLine($"{indent4}{indent1}Control: DatePicker@0.0.46");
                        sb.AppendLine($"{indent4}{indent1}Properties:");
                        sb.AppendLine($"{indent4}{indent2}Appearance: ='DatePickerCanvas.Appearance'.FilledDarker");
                        sb.AppendLine($"{indent4}{indent2}Placeholder: =\"---\"");
                        break;
                    case "dropdown":
                        sb.AppendLine($"{indent4}{indent1}Control: ComboBox@0.0.51");
                        sb.AppendLine($"{indent4}{indent1}Properties:");
                        sb.AppendLine($"{indent4}{indent2}InputTextPlaceholder: =\"---\"");
                        sb.AppendLine($"{indent4}{indent2}Items: =Table({{Value:\"Option 1\"}},{{Value:\"Option 2\"}})");
                        break;
                    default:
                        sb.AppendLine($"{indent4}{indent1}Control: TextInput@0.0.54");
                        sb.AppendLine($"{indent4}{indent1}Properties:");
                        sb.AppendLine($"{indent4}{indent2}Placeholder: =\"---\"");
                        sb.AppendLine($"{indent4}{indent2}Value: =");
                        break;
                }
                index++;
            }

            return sb.ToString();
        }
    }
}
