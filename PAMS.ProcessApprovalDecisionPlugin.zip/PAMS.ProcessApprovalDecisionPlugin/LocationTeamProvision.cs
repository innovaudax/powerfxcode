﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.ServiceModel;

namespace Pams.Plugins
{
    /// <summary>
    /// Provisions a Dataverse owner Team for a pams_location row and stamps the team back
    /// onto pams_location.pams_ownerteamid. Flat model: every location row gets a team.
    /// Membership is managed manually (Morton "just use Owner Teams"), so this does NOT
    /// auto-enroll anyone.
    ///
    /// Registration (two entry points, one shared method):
    ///   1) Create of pams_location -- Post-Operation, Synchronous
    ///      (a new location is added -> its team is created)
    ///   2) Custom API "pams_ProvisionLocationTeam" with input param "LocationId" (String/Guid)
    ///      (backfill existing locations + on-demand re-run; idempotent)
    ///
    /// Teams are created in the ROOT business unit.
    ///
    /// IMPORTANT: the executing identity must have privileges to create Team records.
    /// Register the step to run as a service account with those privileges if needed.
    /// </summary>
    public sealed class LocationTeamProvisioningPlugin : IPlugin
    {
        private const string EntityLocation = "pams_location";
        private const string FieldLocName = "pams_locationname";  // primary name (confirm in your env)
        private const string FieldOwnerTeam = "pams_ownerteamid";   // lookup -> team

        private const string TeamNamePrefix = "LOC - ";

        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            var factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            var service = factory.CreateOrganizationService(context.UserId);

            try
            {
                Guid locationId = ResolveTargetLocationId(context, tracing);
                if (locationId == Guid.Empty)
                {
                    tracing.Trace("No resolvable location id; nothing to do.");
                    return;
                }

                ProvisionTeam(service, tracing, locationId);
            }
            catch (FaultException<OrganizationServiceFault> fault)
            {
                tracing.Trace("OrganizationServiceFault: {0}", fault.ToString());
                throw new InvalidPluginExecutionException("Location team provisioning failed: " + fault.Message, fault);
            }
            catch (Exception ex)
            {
                tracing.Trace("Unhandled exception: {0}", ex.ToString());
                throw new InvalidPluginExecutionException("Location team provisioning failed: " + ex.Message, ex);
            }
        }

        /// <summary>
        /// Create step: Target is the pams_location Entity.
        /// Custom API: id arrives as InputParameters["LocationId"] (string or Guid).
        /// </summary>
        private Guid ResolveTargetLocationId(IPluginExecutionContext context, ITracingService tracing)
        {
            if (context.InputParameters.Contains("Target") &&
                context.InputParameters["Target"] is Entity target &&
                target.LogicalName == EntityLocation)
            {
                return target.Id;
            }

            if (context.InputParameters.Contains("LocationId"))
            {
                object raw = context.InputParameters["LocationId"];
                if (raw is Guid g) return g;
                if (raw is string s && Guid.TryParse(s, out Guid parsed)) return parsed;
                if (raw is EntityReference er) return er.Id;
                tracing.Trace("LocationId present but not parseable: {0}", raw);
            }
            return Guid.Empty;
        }

        private void ProvisionTeam(IOrganizationService service, ITracingService tracing, Guid locationId)
        {
            // Re-read the row fresh (Create Target may not carry every field).
            Entity loc = service.Retrieve(EntityLocation, locationId,
                new ColumnSet(FieldLocName, FieldOwnerTeam));

            // Idempotency: if already linked to a team, nothing to do.
            var existing = loc.GetAttributeValue<EntityReference>(FieldOwnerTeam);
            if (existing != null && existing.Id != Guid.Empty)
            {
                tracing.Trace("Location {0} already linked to team {1}; skipping.", locationId, existing.Id);
                return;
            }

            string locName = loc.GetAttributeValue<string>(FieldLocName) ?? locationId.ToString();
            Guid teamId = FindOrCreateTeam(service, tracing, locationId, locName);

            // Stamp the team back onto the location.
            var stamp = new Entity(EntityLocation, locationId)
            {
                [FieldOwnerTeam] = new EntityReference("team", teamId)
            };
            service.Update(stamp);
            tracing.Trace("Stamped team {0} onto location {1}.", teamId, locationId);
        }

        private Guid FindOrCreateTeam(IOrganizationService service, ITracingService tracing,
                                      Guid locationId, string locName)
        {
            Guid rootBuId = GetRootBusinessUnitId(service);
            string teamName = BuildTeamName(locName, locationId);

            // Reuse an owner team of the same name if one exists (idempotent re-runs).
            var q = new QueryExpression("team")
            {
                ColumnSet = new ColumnSet("teamid"),
                TopCount = 1,
                Criteria = new FilterExpression(LogicalOperator.And)
            };
            q.Criteria.AddCondition("name", ConditionOperator.Equal, teamName);
            q.Criteria.AddCondition("teamtype", ConditionOperator.Equal, 0); // 0 = Owner team
            var hits = service.RetrieveMultiple(q);
            if (hits.Entities.Count > 0)
            {
                var id = hits.Entities[0].Id;
                tracing.Trace("Found existing team '{0}' = {1}.", teamName, id);
                return id;
            }

            var team = new Entity("team")
            {
                ["name"] = teamName,
                ["description"] = "PAMS owner team for location " + locationId,
                ["businessunitid"] = new EntityReference("businessunit", rootBuId),
                ["teamtype"] = new OptionSetValue(0) // Owner team
            };
            Guid newId = service.Create(team);
            tracing.Trace("Created owner team '{0}' = {1} in root BU {2}.", teamName, newId, rootBuId);
            return newId;
        }

        private static string BuildTeamName(string locName, Guid locationId)
        {
            // Team names must be unique. Location names in this list are already unique,
            // but suffix a short id fragment to be safe against future duplicates.
            string shortId = locationId.ToString("N").Substring(0, 8);
            string baseName = TeamNamePrefix + (locName ?? "Location") + " [" + shortId + "]";
            return baseName.Length > 160 ? baseName.Substring(0, 160) : baseName;
        }

        private Guid GetRootBusinessUnitId(IOrganizationService service)
        {
            var q = new QueryExpression("businessunit")
            {
                ColumnSet = new ColumnSet("businessunitid"),
                TopCount = 1,
                Criteria = new FilterExpression()
            };
            q.Criteria.AddCondition("parentbusinessunitid", ConditionOperator.Null);
            var res = service.RetrieveMultiple(q);
            if (res.Entities.Count == 0)
                throw new InvalidPluginExecutionException("Root business unit could not be located.");
            return res.Entities[0].Id;
        }
    }
}